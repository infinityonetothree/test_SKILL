# image-architecture-md-enricher

该 Skill 只要求输入图片。Markdown 为可选输入。

版本 0.7.1 新增经过视觉复检的双通道直播精选分发案例，并记录空布局行和语义链路换行的处理方式。

## 1. 两种使用方式

### 独立描述与 AI 语义重绘

```text
图片
→ 图片清单
→ Agent 视觉解析
→ figure_manifest.json
→ architecture_description.md
→ AI标准化语义重绘
→ SVG + PNG + ai_diagram_manifest.json
→ 将重绘图引用回写 Markdown
```

### 增强已有 Markdown

```text
图片 + summary.md
→ 图片清单
→ Agent 视觉解析
→ figure_manifest.json
→ summary_enriched.md
```

## 2. 文件结构

```text
image-architecture-md-enricher/
├── SKILL.md
├── README.md
├── VERSION
├── requirements.txt
├── scripts/
│   ├── prepare_images.py
│   ├── build_markdown.py
│   ├── generate_ai_diagrams.py
│   ├── layout_preserving_renderer.py
│   ├── prepare_visual_review.py
│   ├── apply_visual_review.py
│   └── validate_output.py
├── schemas/
│   ├── image_inventory.schema.json
│   ├── figure_manifest.schema.json
│   └── ai_diagram_manifest.schema.json
├── templates/
│   ├── architecture_block.md
│   ├── streaming_architecture_block.md
│   └── standard_figure_block.md
├── examples/
│   ├── figure_manifest.example.json
│   ├── streaming_figure_manifest.example.json
│   ├── ai_diagram_manifest.example.json
│   ├── layout_preserving_live_production.example.json
│   ├── visual_review_manifest.example.json
│   ├── source_summary.example.md
│   └── two-channel-live-distribution/
│       ├── source.png
│       ├── figure_manifest.json
│       └── example.md
└── tools/
    ├── install_dependencies.ps1
    └── package_skill.ps1
```

## 3. 本机编辑

推荐使用 VS Code。

必须注意：

- 文件夹名称应为 `image-architecture-md-enricher`；
- `SKILL.md` 不能变成 `SKILL.md.txt`；
- 所有文本文件使用 UTF-8；
- 不要写死当前电脑的绝对路径；
- 不要把 `.venv`、缓存、测试图片和输出目录放入迁移包。

## 4. 静态检查

进入 Skill 根目录：

```powershell
cd D:\agent-skill-work\image-architecture-md-enricher
```

检查 Python：

```powershell
python -m py_compile scripts\prepare_images.py
python -m py_compile scripts\build_markdown.py
python -m py_compile scripts\generate_ai_diagrams.py
python -m py_compile scripts\validate_output.py
```

检查 JSON：

```powershell
python -m json.tool schemas\image_inventory.schema.json > $null
python -m json.tool schemas\figure_manifest.schema.json > $null
python -m json.tool schemas\ai_diagram_manifest.schema.json > $null
python -m json.tool examples\figure_manifest.example.json > $null
python -m json.tool examples\ai_diagram_manifest.example.json > $null
```

## 5. 安装依赖

```powershell
powershell -ExecutionPolicy Bypass -File tools\install_dependencies.ps1
```

## 6. 准备图片

单张图片：

```powershell
python scripts\prepare_images.py `
  --input "D:\test\architecture.png" `
  --output-dir "D:\test\output"
```

多张图片或目录：

```powershell
python scripts\prepare_images.py `
  --input "D:\test\architecture.png" `
  --input "D:\test\figures" `
  --output-dir "D:\test\output"
```

## 7. 生成 Markdown

无原始 Markdown：

```powershell
python scripts\build_markdown.py `
  --manifest "D:\test\output\manifests\figure_manifest.json" `
  --output "D:\test\output\architecture_description.md" `
  --title "系统架构图解析"
```

在未提供 `--source-md` 时，`build_markdown.py` 默认继续生成：

```text
assets/ai_reconstructed/*.svg
assets/ai_reconstructed/*.png
manifests/ai_diagram_manifest.json
```

并将“AI标准化重绘图”自动插入 `architecture_description.md`。使用
`--skip-ai-images` 可以关闭该后处理。

也可以单独执行：

```powershell
python scripts\generate_ai_diagrams.py `
  --markdown "D:\test\output\architecture_description.md" `
  --manifest "D:\test\output\manifests\figure_manifest.json" `
  --output-dir "D:\test\output"
```

有原始 Markdown：

```powershell
python scripts\build_markdown.py `
  --manifest "D:\test\output\manifests\figure_manifest.json" `
  --source-md "D:\test\summary.md" `
  --output "D:\test\output\summary_enriched.md"
```

## 8. 校验

```powershell
python scripts\validate_output.py `
  --markdown "D:\test\output\architecture_description.md" `
  --manifest "D:\test\output\manifests\figure_manifest.json" `
  --inventory "D:\test\output\manifests\image_inventory.json" `
  --report "D:\test\output\reports\validation_report.md" `
  --require-ai-images
```

## 9. 打包迁移

```powershell
powershell -ExecutionPolicy Bypass -File tools\package_skill.ps1
```

会在 Skill 上一级生成：

```text
image-architecture-md-enricher.zip
```

## 10. 目标 Agent 端首次测试指令

### 仅图片

```text
请使用 image-architecture-md-enricher Skill 分析以下图片目录：

D:\test\images

输出目录：

D:\test\output

不提供原始 Markdown。请生成可独立阅读的 Markdown 文档，逐张说明图片类型、
架构模块、信息流、背景颜色、颜色分组、排版、箭头和层级，并在末尾生成资源分类汇总。
```

### 图片加 Markdown

```text
请使用 image-architecture-md-enricher Skill 处理：

图片目录：D:\test\images
已有总结：D:\test\summary.md
输出目录：D:\test\output

不要覆盖原始 Markdown。将图片和解析插入相关章节，并生成资源分类汇总和校验报告。
```


## 11. 点播与直播业务架构测试

点直播类图片推荐使用以下提示词：

```text
请使用 image-architecture-md-enricher Skill 分析这张点播/直播业务架构图。
请先判断它是纯直播、纯点播还是点播直播融合架构，再分别解析：
1. 业务参与者和业务场景；
2. 直播媒体链路；
3. 点播媒体链路；
4. 弹幕、评论、礼物或连麦等互动链路；
5. 商品、订单、支付和结算等业务流与资金流；
6. 存储、CDN、边缘节点、协议、安全和治理能力；
7. 背景、颜色、分层、箭头和视觉分组。
图中没有明确展示的能力不要自行补充。
```

新增示例：

```text
examples/streaming_figure_manifest.example.json
```


## 12. AI可识别语义重绘的定义

生成的重绘图不是对原图做截图或像素复刻，而是将 Markdown 中的业务说明、
模块清单和链路说明，与 `figure_manifest.json` 中的结构化关系结合，生成便于
视觉模型再次识别的标准图。其约束包括：

- 白色或浅色纯背景；
- 高对比度文字和边框；
- 每个模块都有显式编号；
- 不使用仅图标、无文字的节点；
- 不使用渐变和复杂阴影；
- 媒体流、消息流、控制流、数据流、业务流和资金流使用固定图例；
- 使用分层泳道表达参与者、直播链路、点播链路、互动链路和平台能力；
- SVG 中写入机器可读元数据；
- 同时输出 PNG，便于不支持 SVG 的模型读取。

这是一种“语义重绘”，重点是可读性、结构稳定性和信息覆盖，不保证保持原图的
像素位置、品牌图标和视觉风格。


## 13. 方案 C：结构保真重绘

方案 C 适合以下图片：

- 顶部是处理阶段列；
- 左侧是业务行或并行会场；
- 每一行沿相同阶段向右处理；
- 右侧存在汇聚、精选、分发和第三方平台；
- 方框位置和折线关系是图的核心语义。

Agent 不需要检测像素坐标，而是输出一个近似原图的网格：

```text
column_headers + row_headers + grid_nodes + grid_edges
```

默认输出两套图片：

```text
fig_001_ai.png / .svg       # 语义标准化图
fig_001_ai_layout.png/.svg  # 结构保真图
```

结构保真图保证：

- 列顺序不变；
- 行顺序不变；
- 并行业务行不被打散；
- 跨行汇聚模块仍然跨行；
- 连接使用正交折线；
- 汇聚后再精选、再分发的顺序不变。

它不保证：

- 像素位置完全一致；
- 原始图标完全复刻；
- 复杂曲线和装饰元素完全还原。

完整示例：

```text
examples/layout_preserving_live_production.example.json
```


## 14. 完整性防护

v0.6.0 执行：原图逐项盘点 → source_elements/required_texts → 动态重绘 → rendered_texts → 100%覆盖校验。长文字不再使用省略号，容器成员不再只绘制前若干项。


## 15. 生成后 AI 视觉复检

### 第一步：生成对照材料

```powershell
python scripts\prepare_visual_review.py `
  --inventory "D:\test\output\manifests\image_inventory.json" `
  --figure-manifest "D:\test\output\manifests\figure_manifest.json" `
  --ai-manifest "D:\test\output\manifests\ai_diagram_manifest.json" `
  --output-dir "D:\test\output" `
  --iteration 1
```

### 第二步：由视觉 Agent 对照检查

Agent 必须打开原图、结构保真图和语义图，填写：

```text
manifests/visual_review_manifest.json
```

程序不会代替视觉 Agent 做主观视觉判断。

### 第三步：复检失败时应用修订

```powershell
python scripts\apply_visual_review.py `
  --figure-manifest "D:\test\output\manifests\figure_manifest.json" `
  --review-manifest "D:\test\output\manifests\visual_review_manifest.json"
```

然后重新生成并进入下一轮复检。

### 第四步：最终校验

```powershell
python scripts\validate_output.py `
  --markdown "D:\test\output\architecture_description.md" `
  --manifest "D:\test\output\manifests\figure_manifest.json" `
  --inventory "D:\test\output\manifests\image_inventory.json" `
  --report "D:\test\output\reports\validation_report.md" `
  --require-ai-images `
  --require-visual-review
```

视觉复检结果通过文件哈希绑定到当前原图和当前重绘图。重绘图发生任何变化后，旧复检结果会自动失效。
