# 双通道直播精选分发案例

## 用途

使用本案例处理以下结构：

- 顶部按阶段分列；
- 两条上下平行的直播制作链路；
- 独立监控节点；
- 多路频道在跨行节点汇聚；
- 导播能力和第三方平台使用纵向容器表达。

不要将案例中的名称或连接当作通用直播架构知识。新任务只能保留原图明确展示的元素。

## 文件

- `source.png`：可回放的原始架构图。
- `figure_manifest.json`：经过两轮视觉复检的完整 Manifest，包含语义字段、网格布局、覆盖控制和十条媒体连接。

## 回放

从 Skill 根目录执行：

```powershell
python scripts\prepare_images.py `
  --input "examples\two-channel-live-distribution\source.png" `
  --output-dir "<输出目录>"

Copy-Item `
  "examples\two-channel-live-distribution\figure_manifest.json" `
  "<输出目录>\manifests\figure_manifest.json"

python scripts\build_markdown.py `
  --manifest "<输出目录>\manifests\figure_manifest.json" `
  --output "<输出目录>\architecture_description.md" `
  --title "多会场直播制作与精选分发架构解析"
```

随后必须查看原图、语义图、结构保真图和对照板，填写视觉复检清单并运行最终校验。

## 关键建模决策

1. 将图片判定为 `live_streaming_architecture`，不补充图中没有的点播、存储、协议或安全能力。
2. 使用 `matrix_columnar` 保留七个阶段列和两条并行制作链路。
3. 为统一监控保留专用布局行；该行没有可见行标题，因此使用空标题和白色填充隐藏行标题块。
4. 使用 `merge_bar` 表达“精选2路”，使用 `container` 表达自建云导播台，使用 `external_platform` 表达第三方平台集合。
5. 在结构保真图中保留全部节点、成员和连接；在语义图中合并相邻步骤，使直播链路保持单行，避免换行后的长斜线穿框。
6. 将阶段标题、节点、容器成员和连接全部纳入 `coverage_control`，要求元素覆盖率和文字覆盖率均为 100%。

## 验收

- 同时生成语义标准化 SVG/PNG 和结构保真 SVG/PNG；
- 七个阶段标题、十二个主要节点/容器和十条媒体连接均存在；
- `element_coverage_ratio = 1.0`；
- `text_coverage_ratio = 1.0`；
- 视觉复检没有漏项、错字、错连、穿框连线或空白色块。
