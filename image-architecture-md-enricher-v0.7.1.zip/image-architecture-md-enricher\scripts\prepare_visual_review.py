#!/usr/bin/env python3
"""Prepare side-by-side visual review material after diagram generation.

This script does not perform the visual judgment itself. It creates review
boards, file hashes, a review request, and a fillable review-manifest template
for the Agent to inspect using its visual capability.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from PIL import Image, ImageDraw, ImageFont, ImageOps


def load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_json(data: Dict[str, Any]) -> str:
    payload = json.dumps(data, ensure_ascii=False, sort_keys=True).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def find_font(size: int, bold: bool = False):
    candidates: List[Path] = []
    if sys.platform.startswith("win"):
        base = Path("C:/Windows/Fonts")
        candidates += [
            base / ("msyhbd.ttc" if bold else "msyh.ttc"),
            base / ("simhei.ttf" if bold else "simsun.ttc"),
        ]
    elif sys.platform == "darwin":
        candidates += [
            Path("/System/Library/Fonts/PingFang.ttc"),
            Path("/System/Library/Fonts/STHeiti Medium.ttc"),
        ]
    else:
        candidates += [
            Path(
                "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"
                if bold
                else "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
            ),
            Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
        ]
    for candidate in candidates:
        if candidate.exists():
            try:
                return ImageFont.truetype(str(candidate), size=size)
            except Exception:
                continue
    return ImageFont.load_default()


def fit_panel(image: Image.Image, max_width: int, max_height: int) -> Image.Image:
    image = ImageOps.exif_transpose(image).convert("RGB")
    scale = min(max_width / image.width, max_height / image.height, 1.0)
    new_size = (
        max(1, round(image.width * scale)),
        max(1, round(image.height * scale)),
    )
    return image.resize(new_size, Image.Resampling.LANCZOS)


def draw_panel(
    canvas: Image.Image,
    panel: Image.Image,
    x: int,
    y: int,
    width: int,
    height: int,
    title: str,
    subtitle: str,
) -> None:
    draw = ImageDraw.Draw(canvas)
    title_font = find_font(25, bold=True)
    subtitle_font = find_font(15)
    draw.rounded_rectangle(
        (x, y, x + width, y + height),
        radius=14,
        fill="#F7F9FB",
        outline="#90A4AE",
        width=2,
    )
    draw.text((x + 18, y + 13), title, fill="#102027", font=title_font)
    draw.text((x + 18, y + 49), subtitle, fill="#546E7A", font=subtitle_font)
    image_area_top = y + 78
    available_height = height - 96
    px = x + (width - panel.width) // 2
    py = image_area_top + (available_height - panel.height) // 2
    canvas.paste(panel, (px, py))
    draw.rectangle(
        (px, py, px + panel.width, py + panel.height),
        outline="#B0BEC5",
        width=1,
    )


def create_board(
    source_path: Path,
    semantic_path: Path,
    layout_path: Optional[Path],
    output_path: Path,
    figure_id: str,
    iteration: int,
) -> None:
    panel_width = 1180
    panel_height = 820
    gap = 28
    margin = 36
    header_height = 105

    panels: List[Tuple[str, Path]] = [("原始图片", source_path)]
    if layout_path is not None and layout_path.exists():
        panels.append(("结构保真重绘", layout_path))
    panels.append(("语义标准化重绘", semantic_path))

    width = margin * 2 + len(panels) * panel_width + (len(panels) - 1) * gap
    height = header_height + panel_height + margin
    canvas = Image.new("RGB", (width, height), "#FFFFFF")
    draw = ImageDraw.Draw(canvas)
    title_font = find_font(32, bold=True)
    body_font = find_font(17)
    draw.text(
        (margin, 25),
        f"{figure_id} 生成后视觉复检 · 第 {iteration} 轮",
        fill="#102027",
        font=title_font,
    )
    draw.text(
        (margin, 70),
        "必须同时检查元素、文字、连线、布局和可读性；不能只看文件是否存在。",
        fill="#455A64",
        font=body_font,
    )

    for index, (title, path) in enumerate(panels):
        with Image.open(path) as opened:
            panel = fit_panel(opened, panel_width - 34, panel_height - 112)
        x = margin + index * (panel_width + gap)
        draw_panel(
            canvas,
            panel,
            x,
            header_height,
            panel_width,
            panel_height,
            title,
            f"{path.name} · {Image.open(path).size[0]}×{Image.open(path).size[1]}",
        )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(output_path, "PNG", optimize=True)


def resolve_asset(root: Path, relative: str) -> Path:
    return root / Path(relative.replace("\\", "/"))


def run_prepare(
    inventory_path: Path,
    figure_manifest_path: Path,
    ai_manifest_path: Path,
    output_dir: Path,
    iteration: int = 1,
) -> Dict[str, Any]:
    inventory_path = inventory_path.expanduser().resolve()
    figure_manifest_path = figure_manifest_path.expanduser().resolve()
    ai_manifest_path = ai_manifest_path.expanduser().resolve()
    output_dir = output_dir.expanduser().resolve()

    inventory = load_json(inventory_path)
    figure_manifest = load_json(figure_manifest_path)
    ai_manifest = load_json(ai_manifest_path)

    inventory_by_id = {
        str(item.get("image_id", "")): item for item in inventory.get("images", [])
    }
    figure_by_id = {
        str(item.get("figure_id", "")): item for item in figure_manifest.get("figures", [])
    }

    review_dir = output_dir / "assets" / "visual_review"
    manifests_dir = output_dir / "manifests"
    reports_dir = output_dir / "reports"
    review_dir.mkdir(parents=True, exist_ok=True)
    manifests_dir.mkdir(parents=True, exist_ok=True)
    reports_dir.mkdir(parents=True, exist_ok=True)

    ai_manifest_hash = sha256_file(ai_manifest_path)
    review_items: List[Dict[str, Any]] = []

    for diagram in ai_manifest.get("diagrams", []):
        figure_id = str(diagram.get("figure_id", ""))
        diagram_id = str(diagram.get("diagram_id", ""))
        figure = figure_by_id.get(figure_id)
        if not figure:
            continue
        image = inventory_by_id.get(str(figure.get("image_id", "")))
        if not image:
            continue

        source_path = resolve_asset(output_dir, str(image.get("asset_path", "")))
        semantic_path = resolve_asset(output_dir, str(diagram.get("png_path", "")))
        layout_relative = str(diagram.get("layout_png_path", ""))
        layout_path = resolve_asset(output_dir, layout_relative) if layout_relative else None

        missing = [
            str(path)
            for path in [source_path, semantic_path, layout_path]
            if path is not None and not path.exists()
        ]
        if missing:
            raise FileNotFoundError("Missing visual review file(s): " + ", ".join(missing))

        board_relative = (
            f"assets/visual_review/"
            f"{figure_id.lower().replace('-', '_')}_iter_{iteration:02d}_comparison.png"
        )
        board_path = output_dir / board_relative
        create_board(
            source_path,
            semantic_path,
            layout_path,
            board_path,
            figure_id,
            iteration,
        )

        item = {
            "figure_id": figure_id,
            "diagram_id": diagram_id,
            "display_name": figure.get("display_name", figure_id),
            "classification": figure.get("classification", "unknown"),
            "review_iteration": iteration,
            "source": {
                "path": str(image.get("asset_path", "")).replace("\\", "/"),
                "sha256": sha256_file(source_path),
                "width": int(image.get("width", 0)),
                "height": int(image.get("height", 0)),
            },
            "semantic_redraw": {
                "path": str(diagram.get("png_path", "")).replace("\\", "/"),
                "sha256": sha256_file(semantic_path),
                "width": int(diagram.get("width", 0)),
                "height": int(diagram.get("height", 0)),
            },
            "layout_redraw": (
                {
                    "path": layout_relative.replace("\\", "/"),
                    "sha256": sha256_file(layout_path),
                    "width": int(diagram.get("layout_width", 0)),
                    "height": int(diagram.get("layout_height", 0)),
                }
                if layout_path is not None
                else None
            ),
            "comparison_board": {
                "path": board_relative,
                "sha256": sha256_file(board_path),
            },
            "review_requirements": {
                "element_recall": 1.0,
                "text_accuracy": 1.0,
                "connection_accuracy": 1.0,
                "minimum_layout_fidelity": 0.90,
                "readability_pass": True,
                "no_unresolved_issues": True,
            },
            "mandatory_checks": [
                "逐项核对原图中的标题、方框、列表项、平台名称和有意义图标",
                "逐项核对主连接、分支、汇聚、分发和反馈方向",
                "核对列顺序、行顺序、并行链路和跨行模块",
                "核对错字、漏字、重复字、截断和异常换行",
                "检查文字重叠、越界、字号过小、连线穿框和箭头遮挡",
                "检查重绘图是否增加了原图不存在的模块或连接",
            ],
        }
        review_items.append(item)

    request = {
        "request_version": "1.0",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "review_iteration": iteration,
        "maximum_review_iterations": 3,
        "output_root": str(output_dir),
        "inventory_path": str(inventory_path),
        "figure_manifest_path": str(figure_manifest_path),
        "ai_diagram_manifest_path": str(ai_manifest_path),
        "ai_diagram_manifest_sha256": ai_manifest_hash,
        "instructions": [
            "Agent 必须实际打开原图、结构保真图和语义图；对照图仅用于概览。",
            "不得仅根据 Manifest 宣布通过。",
            "发现问题时必须在 visual_review_manifest.json 中列出，并生成 revision_operations。",
            "复检通过前不得将任务标记为完成。",
        ],
        "review_items": review_items,
    }
    request_path = manifests_dir / "visual_review_request.json"
    request_path.write_text(
        json.dumps(request, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    request_hash = sha256_file(request_path)

    template_reviews = []
    for item in review_items:
        template_reviews.append(
            {
                "figure_id": item["figure_id"],
                "diagram_id": item["diagram_id"],
                "review_iteration": iteration,
                "review_status": "pending",
                "reviewed_files": {
                    "source_path": item["source"]["path"],
                    "source_sha256": item["source"]["sha256"],
                    "semantic_png_path": item["semantic_redraw"]["path"],
                    "semantic_png_sha256": item["semantic_redraw"]["sha256"],
                    "layout_png_path": (
                        item["layout_redraw"]["path"]
                        if item["layout_redraw"]
                        else ""
                    ),
                    "layout_png_sha256": (
                        item["layout_redraw"]["sha256"]
                        if item["layout_redraw"]
                        else ""
                    ),
                    "comparison_board_path": item["comparison_board"]["path"],
                    "comparison_board_sha256": item["comparison_board"]["sha256"],
                },
                "metrics": {
                    "element_recall": 0.0,
                    "text_accuracy": 0.0,
                    "connection_accuracy": 0.0,
                    "layout_fidelity": 0.0,
                    "readability_score": 0.0,
                },
                "readability_pass": False,
                "missing_elements": [],
                "extra_elements": [],
                "incorrect_texts": [],
                "missing_connections": [],
                "incorrect_connections": [],
                "layout_issues": [],
                "readability_issues": [],
                "unresolved_issues": [],
                "revision_required": True,
                "revision_operations": [],
                "review_notes": "",
            }
        )

    template = {
        "review_version": "1.0",
        "review_iteration": iteration,
        "review_request_sha256": request_hash,
        "ai_diagram_manifest_sha256": ai_manifest_hash,
        "reviewed_at_utc": "",
        "reviewer": "visual_agent",
        "reviews": template_reviews,
    }
    template_path = manifests_dir / "visual_review_manifest.template.json"
    template_path.write_text(
        json.dumps(template, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    report_lines = [
        "# Visual Review Request",
        "",
        f"- 复检轮次：{iteration}",
        f"- 待复检图片：{len(review_items)}",
        f"- AI重绘清单 SHA-256：`{ai_manifest_hash}`",
        "",
        "## 复检要求",
        "",
        "- 必需元素召回率：100%",
        "- 必需文字准确率：100%",
        "- 主要连接准确率：100%",
        "- 布局保真度：不低于 0.90",
        "- 无文字重叠、越界和不可读问题",
        "- 无未解决问题",
        "",
    ]
    for item in review_items:
        report_lines += [
            f"## {item['figure_id']}：{item['display_name']}",
            "",
            f"- 原图：`{item['source']['path']}`",
            f"- 结构保真图：`{item['layout_redraw']['path'] if item['layout_redraw'] else '无'}`",
            f"- 语义图：`{item['semantic_redraw']['path']}`",
            f"- 对照图：`{item['comparison_board']['path']}`",
            "",
        ]
    (reports_dir / "visual_review_request.md").write_text(
        "\n".join(report_lines),
        encoding="utf-8",
    )

    print(f"Created: {request_path}")
    print(f"Created: {template_path}")
    print(f"Visual review items: {len(review_items)}")
    return request


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inventory", required=True)
    parser.add_argument("--figure-manifest", required=True)
    parser.add_argument("--ai-manifest", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--iteration", type=int, default=1)
    args = parser.parse_args()

    if args.iteration < 1 or args.iteration > 3:
        print("ERROR: iteration must be from 1 to 3.", file=sys.stderr)
        return 2
    try:
        run_prepare(
            Path(args.inventory),
            Path(args.figure_manifest),
            Path(args.ai_manifest),
            Path(args.output_dir),
            args.iteration,
        )
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 3
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
