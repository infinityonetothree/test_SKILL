#!/usr/bin/env python3
"""Apply deterministic visual-review revision operations to figure_manifest.json."""

from __future__ import annotations

import argparse
import copy
import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List


def load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def find_by_id(items: List[Dict[str, Any]], id_field: str, target_id: str):
    for item in items:
        if str(item.get(id_field, "")) == target_id:
            return item
    return None


def dotted_set(target: Dict[str, Any], path: str, value: Any) -> None:
    parts = [part for part in path.split(".") if part]
    if not parts:
        raise ValueError("Empty field path.")
    current = target
    for part in parts[:-1]:
        if part not in current or not isinstance(current[part], dict):
            current[part] = {}
        current = current[part]
    current[parts[-1]] = value


def apply_operation(figure: Dict[str, Any], operation: Dict[str, Any]) -> None:
    op = str(operation.get("operation", ""))
    target_id = str(operation.get("target_id", ""))
    value = copy.deepcopy(operation.get("value"))
    changes = copy.deepcopy(operation.get("changes", {}))

    layout = figure.setdefault("layout_preservation", {})
    nodes = layout.setdefault("grid_nodes", [])
    edges = layout.setdefault("grid_edges", [])
    columns = layout.setdefault("column_headers", [])
    rows = layout.setdefault("row_headers", [])
    coverage = figure.setdefault(
        "coverage_control",
        {
            "coverage_target": 1.0,
            "source_elements": [],
            "required_texts": [],
            "allow_ignored_required_elements": False,
        },
    )
    source_elements = coverage.setdefault("source_elements", [])
    required_texts = coverage.setdefault("required_texts", [])

    if op == "add_node":
        if not isinstance(value, dict) or not value.get("node_id"):
            raise ValueError("add_node requires value.node_id.")
        if find_by_id(nodes, "node_id", str(value["node_id"])):
            raise ValueError(f"Node already exists: {value['node_id']}")
        nodes.append(value)
    elif op == "update_node":
        node = find_by_id(nodes, "node_id", target_id)
        if node is None:
            raise ValueError(f"Node not found: {target_id}")
        node.update(changes)
    elif op == "remove_node":
        layout["grid_nodes"] = [
            node for node in nodes if str(node.get("node_id", "")) != target_id
        ]
        layout["grid_edges"] = [
            edge
            for edge in edges
            if str(edge.get("source", "")) != target_id
            and str(edge.get("target", "")) != target_id
        ]
    elif op == "add_edge":
        if not isinstance(value, dict) or not value.get("edge_id"):
            raise ValueError("add_edge requires value.edge_id.")
        if find_by_id(edges, "edge_id", str(value["edge_id"])):
            raise ValueError(f"Edge already exists: {value['edge_id']}")
        edges.append(value)
    elif op == "update_edge":
        edge = find_by_id(edges, "edge_id", target_id)
        if edge is None:
            raise ValueError(f"Edge not found: {target_id}")
        edge.update(changes)
    elif op == "remove_edge":
        layout["grid_edges"] = [
            edge for edge in edges if str(edge.get("edge_id", "")) != target_id
        ]
    elif op == "update_column":
        column = find_by_id(columns, "column_id", target_id)
        if column is None:
            raise ValueError(f"Column not found: {target_id}")
        column.update(changes)
    elif op == "update_row":
        row = find_by_id(rows, "row_id", target_id)
        if row is None:
            raise ValueError(f"Row not found: {target_id}")
        row.update(changes)
    elif op == "add_required_text":
        text = str(value or "").strip()
        if text and text not in required_texts:
            required_texts.append(text)
    elif op == "remove_required_text":
        text = str(value or "").strip()
        coverage["required_texts"] = [item for item in required_texts if item != text]
    elif op == "add_source_element":
        if not isinstance(value, dict) or not value.get("element_id"):
            raise ValueError("add_source_element requires value.element_id.")
        if find_by_id(source_elements, "element_id", str(value["element_id"])):
            raise ValueError(f"Source element already exists: {value['element_id']}")
        source_elements.append(value)
    elif op == "update_source_element":
        element = find_by_id(source_elements, "element_id", target_id)
        if element is None:
            raise ValueError(f"Source element not found: {target_id}")
        element.update(changes)
    elif op == "set_figure_field":
        field_path = str(operation.get("field_path", ""))
        dotted_set(figure, field_path, value)
    else:
        raise ValueError(f"Unsupported revision operation: {op}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--figure-manifest", required=True)
    parser.add_argument("--review-manifest", required=True)
    parser.add_argument("--output")
    args = parser.parse_args()

    figure_path = Path(args.figure_manifest).expanduser().resolve()
    review_path = Path(args.review_manifest).expanduser().resolve()
    output_path = (
        Path(args.output).expanduser().resolve()
        if args.output
        else figure_path
    )

    try:
        manifest = load_json(figure_path)
        review = load_json(review_path)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    figures = {
        str(item.get("figure_id", "")): item for item in manifest.get("figures", [])
    }
    applied = 0
    errors: List[str] = []

    for item in review.get("reviews", []):
        if not item.get("revision_required", False):
            continue
        figure_id = str(item.get("figure_id", ""))
        figure = figures.get(figure_id)
        if figure is None:
            errors.append(f"Figure not found: {figure_id}")
            continue
        for operation in item.get("revision_operations", []):
            try:
                apply_operation(figure, operation)
                applied += 1
            except Exception as exc:
                errors.append(f"{figure_id}: {exc}")
        state = figure.setdefault("visual_review_state", {})
        state["last_review_iteration"] = int(item.get("review_iteration", 0))
        state["last_review_status"] = str(item.get("review_status", "fail"))
        state["revision_count"] = int(state.get("revision_count", 0)) + 1
        state["last_review_manifest"] = str(review_path)
        state["updated_at_utc"] = datetime.now(timezone.utc).isoformat()

    if errors:
        print("ERROR: one or more operations failed:", file=sys.stderr)
        for error in errors:
            print(f" - {error}", file=sys.stderr)
        return 3

    output_path.parent.mkdir(parents=True, exist_ok=True)
    if output_path == figure_path:
        backup = figure_path.with_suffix(
            figure_path.suffix + f".before_review_{review.get('review_iteration', 0)}.bak"
        )
        shutil.copy2(figure_path, backup)
        print(f"Backup: {backup}")

    output_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"Created: {output_path}")
    print(f"Applied revision operations: {applied}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
