#!/usr/bin/env python3
"""Validate generated Markdown, image inventory, and figure manifest."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List


STREAMING_TYPES = {
    "media_streaming_business_architecture", "live_streaming_architecture",
    "vod_architecture", "live_vod_converged_architecture",
    "live_ecommerce_architecture", "interactive_live_architecture",
    "media_processing_pipeline", "streaming_distribution_architecture",
}
ARCHITECTURE_TYPES = {
    "system_architecture", "business_architecture", "layered_architecture",
    "data_flow", "workflow", "module_block_diagram", "training_pipeline",
    "control_architecture", "network_architecture", "deployment_architecture",
} | STREAMING_TYPES


def load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def markdown_image_paths(markdown: str) -> List[str]:
    return re.findall(r"!\[[^\]]*\]\(([^)]+)\)", markdown)


def nonempty_list(value: Any) -> bool:
    return isinstance(value, list) and len(value) > 0


def flow_types(figure: Dict[str, Any]) -> set[str]:
    result: set[str] = set()
    for item in figure.get("business_flows", []):
        if isinstance(item, dict):
            result.add(str(item.get("flow_type", "")))
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--markdown", required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--inventory", required=True)
    parser.add_argument("--report", required=True)
    parser.add_argument("--assets-root", help="Base directory for asset paths; defaults to Markdown parent.")
    parser.add_argument("--ai-manifest", help="Optional AI redraw manifest; defaults to manifests/ai_diagram_manifest.json beside figure manifest.")
    parser.add_argument("--require-ai-images", action="store_true", help="Fail if AI-readable semantic redraws are missing.")
    args = parser.parse_args()
    markdown_path = Path(args.markdown).expanduser().resolve()
    manifest_path = Path(args.manifest).expanduser().resolve()
    inventory_path = Path(args.inventory).expanduser().resolve()
    report_path = Path(args.report).expanduser().resolve()
    ai_manifest_path = (
        Path(args.ai_manifest).expanduser().resolve()
        if args.ai_manifest
        else manifest_path.parent / "ai_diagram_manifest.json"
    )
    assets_root = Path(args.assets_root).expanduser().resolve() if args.assets_root else markdown_path.parent
    errors: List[str] = []
    warnings: List[str] = []
    passed: List[str] = []
    try:
        markdown = markdown_path.read_text(encoding="utf-8")
        manifest = load_json(manifest_path)
        inventory = load_json(inventory_path)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    inventory_images = inventory.get("images", [])
    inventory_ids = {str(image.get("image_id", "")): image for image in inventory_images}
    figures = manifest.get("figures", [])
    retained = [figure for figure in figures if figure.get("retain", True) and figure.get("classification") != "decorative"]
    figure_ids = [str(figure.get("figure_id", "")) for figure in retained]
    duplicates = sorted({item for item in figure_ids if item and figure_ids.count(item) > 1})
    if duplicates:
        errors.append(f"重复资源编号：{', '.join(duplicates)}")
    else:
        passed.append("资源编号唯一。")
    used_image_ids: List[str] = []
    for figure in retained:
        figure_id = str(figure.get("figure_id", ""))
        image_id = str(figure.get("image_id", ""))
        used_image_ids.append(image_id)
        if image_id not in inventory_ids:
            errors.append(f"{figure_id} 引用了不存在的图片编号：{image_id}")
        if f"<!-- figure:{figure_id}:start -->" not in markdown:
            errors.append(f"{figure_id} 未插入 Markdown。")
        asset_path = str(figure.get("asset_path", "")).replace("\\", "/")
        if not asset_path:
            errors.append(f"{figure_id} 缺少 asset_path。")
        else:
            resolved = assets_root / Path(asset_path)
            if not resolved.exists():
                errors.append(f"{figure_id} 的资源文件不存在：{resolved}")
        classification = figure.get("classification")
        if classification in ARCHITECTURE_TYPES:
            if not str(figure.get("architecture_description", "")).strip():
                errors.append(f"{figure_id} 缺少 architecture_description。")
            if not str(figure.get("visual_description", "")).strip():
                errors.append(f"{figure_id} 缺少 visual_description。")
            if not isinstance(figure.get("layout"), dict):
                warnings.append(f"{figure_id} 缺少结构化 layout。")
            if not isinstance(figure.get("background"), dict):
                warnings.append(f"{figure_id} 缺少结构化 background。")
        if classification in STREAMING_TYPES:
            profile = figure.get("streaming_profile")
            if not isinstance(profile, dict):
                errors.append(f"{figure_id} 缺少 streaming_profile。")
                profile = {}
            mode = profile.get("delivery_mode")
            if mode not in {"live", "vod", "live_and_vod", "unknown"}:
                errors.append(f"{figure_id} 的 delivery_mode 无效：{mode}")
            if classification not in {"media_processing_pipeline", "streaming_distribution_architecture"} and not nonempty_list(figure.get("business_flows")):
                errors.append(f"{figure_id} 缺少 business_flows。")
            if classification == "media_streaming_business_architecture" and not (nonempty_list(figure.get("live_media_pipeline")) or nonempty_list(figure.get("vod_media_pipeline"))):
                errors.append(f"{figure_id} 点直播总体架构至少需要一条直播或点播媒体链路。")
            if classification == "live_streaming_architecture" and not nonempty_list(figure.get("live_media_pipeline")):
                errors.append(f"{figure_id} 作为直播架构缺少 live_media_pipeline。")
            if classification == "vod_architecture" and not nonempty_list(figure.get("vod_media_pipeline")):
                errors.append(f"{figure_id} 作为点播架构缺少 vod_media_pipeline。")
            if classification == "live_vod_converged_architecture":
                if mode != "live_and_vod":
                    warnings.append(f"{figure_id} 分类为点播直播融合，但 delivery_mode 不是 live_and_vod。")
                if not nonempty_list(figure.get("live_media_pipeline")):
                    errors.append(f"{figure_id} 缺少直播媒体链路。")
                if not nonempty_list(figure.get("vod_media_pipeline")):
                    errors.append(f"{figure_id} 缺少点播媒体链路。")
            if classification == "interactive_live_architecture" and not nonempty_list(figure.get("interaction_pipeline")):
                errors.append(f"{figure_id} 作为互动直播架构缺少 interaction_pipeline。")
            if classification == "live_ecommerce_architecture":
                types = flow_types(figure)
                if "business_flow" not in types:
                    warnings.append(f"{figure_id} 电商直播图未明确记录 business_flow。")
                if "fund_flow" not in types:
                    warnings.append(f"{figure_id} 电商直播图未明确记录 fund_flow。")
            if classification == "media_processing_pipeline" and not (nonempty_list(figure.get("live_media_pipeline")) or nonempty_list(figure.get("vod_media_pipeline"))):
                errors.append(f"{figure_id} 媒体处理流程缺少可解析的媒体链路。")
            if classification == "streaming_distribution_architecture" and not nonempty_list(figure.get("storage_and_distribution")):
                errors.append(f"{figure_id} 流媒体分发架构缺少 storage_and_distribution。")
            if not nonempty_list(figure.get("business_actors")) and classification not in {"media_processing_pipeline", "streaming_distribution_architecture"}:
                warnings.append(f"{figure_id} 未记录业务参与者。")
        confidence = float(figure.get("classification_confidence", 1.0))
        if confidence < 0.75:
            warnings.append(f"{figure_id} 分类置信度低于 0.75。")
        if "insertion_confidence" in figure and float(figure.get("insertion_confidence", 1.0)) < 0.75:
            warnings.append(f"{figure_id} 插入位置置信度低于 0.75。")
        redraw = figure.get("ai_redraw", {})
        redraw_mode = redraw.get("mode", "semantic") if isinstance(redraw, dict) else "semantic"
        layout_data = figure.get("layout_preservation")
        if redraw_mode in {"both", "layout_preserving"}:
            if not isinstance(layout_data, dict) or not layout_data.get("enabled"):
                errors.append(f"{figure_id} 要求结构保真重绘，但缺少启用的 layout_preservation。")
            else:
                if not nonempty_list(layout_data.get("column_headers")):
                    errors.append(f"{figure_id} 的 layout_preservation 缺少 column_headers。")
                if not nonempty_list(layout_data.get("row_headers")):
                    errors.append(f"{figure_id} 的 layout_preservation 缺少 row_headers。")
                if not nonempty_list(layout_data.get("grid_nodes")):
                    errors.append(f"{figure_id} 的 layout_preservation 缺少 grid_nodes。")
                if not isinstance(layout_data.get("grid_edges"), list):
                    errors.append(f"{figure_id} 的 layout_preservation 缺少 grid_edges。")
        if figure.get("review_required", False):
            warnings.append(f"{figure_id} 被标记为需要人工复核。")
    if "<!-- resource-index:start -->" not in markdown or "<!-- resource-index:end -->" not in markdown:
        errors.append("缺少资源分类汇总标记。")
    else:
        passed.append("资源分类汇总存在。")
    for figure_id in figure_ids:
        count = markdown.count(f"资源编号：{figure_id}")
        if count != 1:
            errors.append(f"{figure_id} 在资源分类汇总中出现 {count} 次，应为 1 次。")
    for image_path in markdown_image_paths(markdown):
        if "://" in image_path or image_path.startswith("data:"):
            continue
        resolved = assets_root / Path(image_path.replace("\\", "/"))
        if not resolved.exists():
            errors.append(f"Markdown 图片引用不存在：{resolved}")
    unused = [image_id for image_id in inventory_ids if image_id not in used_image_ids]
    if unused:
        warnings.append("以下输入图片未对应保留资源，可能被分类为装饰图或被遗漏：" + ", ".join(unused))
    else:
        passed.append("所有输入图片均对应至少一个保留资源。")

    ai_diagram_count = 0
    if ai_manifest_path.exists():
        try:
            ai_manifest = load_json(ai_manifest_path)
            ai_diagrams = ai_manifest.get("diagrams", [])
            ai_diagram_count = len(ai_diagrams)
            current_hash = __import__("hashlib").sha256(markdown.encode("utf-8")).hexdigest()
            if ai_manifest.get("final_markdown_sha256") != current_hash:
                errors.append("AI重绘清单中的 final_markdown_sha256 与当前 Markdown 不一致。")
            eligible_ids = {
                str(figure.get("figure_id", ""))
                for figure in retained
                if figure.get("classification") in ARCHITECTURE_TYPES
                and not (
                    isinstance(figure.get("ai_redraw"), dict)
                    and figure["ai_redraw"].get("enabled") is False
                )
            }
            diagram_figure_ids = set()
            for diagram in ai_diagrams:
                diagram_id = str(diagram.get("diagram_id", ""))
                figure_id = str(diagram.get("figure_id", ""))
                diagram_figure_ids.add(figure_id)
                if f"<!-- ai-diagram:{diagram_id}:start -->" not in markdown:
                    errors.append(f"{diagram_id} 未回写到 Markdown。")
                for key in ["png_path", "svg_path"]:
                    rel = str(diagram.get(key, "")).replace("\\", "/")
                    if not rel:
                        errors.append(f"{diagram_id} 缺少 {key}。")
                    elif not (assets_root / Path(rel)).exists():
                        errors.append(f"{diagram_id} 的 {key} 文件不存在：{assets_root / Path(rel)}")
                if int(diagram.get("node_count", 0)) < 1:
                    errors.append(f"{diagram_id} 没有可识别节点。")
                if int(diagram.get("width", 0)) < 1200 or int(diagram.get("height", 0)) < 600:
                    warnings.append(f"{diagram_id} 输出尺寸偏小，可能影响AI识别。")
                readability = diagram.get("ai_readability", {})
                if not (
                    readability.get("high_contrast") is True
                    and readability.get("explicit_node_ids") is True
                    and readability.get("standard_arrow_legend") is True
                    and readability.get("icon_only_nodes") is False
                    and readability.get("gradients") is False
                ):
                    errors.append(f"{diagram_id} 未满足AI可识别重绘规范。")
                if diagram.get("render_mode") == "semantic_and_layout_preserving":
                    for key in ["layout_png_path", "layout_svg_path"]:
                        rel = str(diagram.get(key, "")).replace("\\", "/")
                        if not rel:
                            errors.append(f"{diagram_id} 缺少 {key}。")
                        elif not (assets_root / Path(rel)).exists():
                            errors.append(
                                f"{diagram_id} 的 {key} 文件不存在：{assets_root / Path(rel)}"
                            )
                    if int(diagram.get("layout_column_count", 0)) < 1:
                        errors.append(f"{diagram_id} 结构保真图缺少列结构。")
                    if int(diagram.get("layout_row_count", 0)) < 1:
                        errors.append(f"{diagram_id} 结构保真图缺少行结构。")
                    if int(diagram.get("layout_node_count", 0)) < 1:
                        errors.append(f"{diagram_id} 结构保真图缺少节点。")
                    if f"{diagram.get('layout_png_path', '')}" not in markdown:
                        errors.append(f"{diagram_id} 的结构保真图未回写 Markdown。")
                    fidelity = diagram.get("layout_fidelity", {})
                    if not (
                        fidelity.get("preserves_column_order") is True
                        and fidelity.get("preserves_row_order") is True
                        and fidelity.get("preserves_parallel_rows") is True
                        and fidelity.get("preserves_spanning_nodes") is True
                    ):
                        errors.append(f"{diagram_id} 未满足最小布局保真规范。")
            missing_ai = sorted(eligible_ids - diagram_figure_ids)
            if missing_ai:
                errors.append("以下架构资源缺少AI语义重绘图：" + ", ".join(missing_ai))
            else:
                passed.append("所有启用重绘的架构资源均已生成AI语义重绘图。")
            if "<!-- ai-resource-index:start -->" not in markdown:
                errors.append("Markdown 缺少 AI语义重绘资源索引。")
            else:
                passed.append("AI语义重绘资源索引存在。")
        except Exception as exc:
            errors.append(f"无法读取或校验 AI重绘清单：{exc}")
    elif args.require_ai_images:
        errors.append(f"缺少AI重绘清单：{ai_manifest_path}")
    else:
        warnings.append("未发现AI重绘清单；如果这是Markdown增强模式，可忽略。")
    report_lines = [
        "# Validation Report", "", f"- Markdown：`{markdown_path}`",
        f"- Figure manifest：`{manifest_path}`", f"- Image inventory：`{inventory_path}`",
        f"- 输入图片数量：{len(inventory_images)}", f"- 保留资源数量：{len(retained)}",
        f"- 点直播资源数量：{sum(1 for f in retained if f.get('classification') in STREAMING_TYPES)}",
        f"- AI语义重绘数量：{ai_diagram_count}",
        f"- 错误数量：{len(errors)}", f"- 警告数量：{len(warnings)}", "", "## 结果", "",
        "PASS" if not errors else "FAIL", "",
    ]
    if errors:
        report_lines += ["## 错误", ""] + [f"- {item}" for item in errors] + [""]
    if warnings:
        report_lines += ["## 警告", ""] + [f"- {item}" for item in warnings] + [""]
    if passed:
        report_lines += ["## 已通过检查", ""] + [f"- {item}" for item in passed] + [""]
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text("\n".join(report_lines), encoding="utf-8")
    print(f"Created: {report_path}")
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
