#!/usr/bin/env python3
"""Grid-based layout-preserving renderer.

This is the minimal implementation used by Scheme C. It does not run CV or OCR.
The Agent must encode the original diagram's columns, rows, nodes and edges in
figure_manifest.json. The renderer then reconstructs that grid while preserving
column order, row order, parallel paths, spanning nodes, merge bars and
distribution containers.
"""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from xml.sax.saxutils import escape as xml_escape

from PIL import Image, ImageDraw, ImageFont


FLOW_COLORS = {
    "media_flow": "#1565C0",
    "message_flow": "#7B1FA2",
    "control_flow": "#EF6C00",
    "data_flow": "#00838F",
    "business_flow": "#2E7D32",
    "fund_flow": "#C62828",
    "dependency": "#455A64",
    "unknown": "#616161",
}

DEFAULT_HEADER_COLORS = [
    "#29ABE2", "#0D57B7", "#70278C", "#E40046", "#007A4D",
    "#9B6500", "#00A65A", "#E83A09", "#455A64", "#1565C0",
]

DEFAULT_FONT_FAMILIES = (
    "Microsoft YaHei, Noto Sans CJK SC, PingFang SC, SimHei, sans-serif"
)


def clean_text(value: Any) -> str:
    return " ".join(str(value or "").replace("\n", " ").split())


def find_font(size: int, bold: bool = False):
    candidates: List[Path] = []
    if sys.platform.startswith("win"):
        base = Path("C:/Windows/Fonts")
        candidates += [
            base / ("msyhbd.ttc" if bold else "msyh.ttc"),
            base / ("simhei.ttf" if bold else "simsun.ttc"),
        ]
    elif sys.platform == "darwin":
        candidates += [
            Path("/System/Library/Fonts/PingFang.ttc"),
            Path("/System/Library/Fonts/STHeiti Medium.ttc"),
        ]
    else:
        candidates += [
            Path(
                "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"
                if bold
                else "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
            ),
            Path("/usr/share/fonts/truetype/arphic-gbsn00lp/gbsn00lp.ttf"),
            Path(
                "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
                if bold
                else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
            ),
        ]
    for candidate in candidates:
        if candidate.exists():
            try:
                return ImageFont.truetype(str(candidate), size=size)
            except Exception:
                pass
    return ImageFont.load_default()


def text_lines(text: str, max_chars: int, max_lines: int) -> List[str]:
    text = clean_text(text)
    if not text:
        return [""]
    lines: List[str] = []
    remaining = text
    while remaining and len(lines) < max_lines:
        lines.append(remaining[:max_chars])
        remaining = remaining[max_chars:]
    if remaining and lines:
        lines[-1] = (lines[-1][:-1] if len(lines[-1]) > 1 else "") + "…"
    return lines


def ordered(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return sorted(items, key=lambda item: (int(item.get("order", 9999)), str(item.get("title", ""))))


def layout_data(figure: Dict[str, Any]) -> Dict[str, Any]:
    value = figure.get("layout_preservation")
    return value if isinstance(value, dict) else {}


def is_enabled(figure: Dict[str, Any]) -> bool:
    data = layout_data(figure)
    return bool(data.get("enabled", False) and data.get("column_headers") and data.get("row_headers") and data.get("grid_nodes"))


def calculate_grid(figure: Dict[str, Any]) -> Dict[str, Any]:
    data = layout_data(figure)
    columns = ordered(list(data.get("column_headers", [])))
    rows = ordered(list(data.get("row_headers", [])))
    nodes = list(data.get("grid_nodes", []))
    edges = list(data.get("grid_edges", []))

    if not columns or not rows or not nodes:
        raise ValueError("layout_preservation requires column_headers, row_headers and grid_nodes.")

    margin_left = 55
    row_header_width = 190
    margin_right = 55
    title_height = 95
    column_header_height = 95
    footer_height = 105
    base_col_width = 205
    base_row_height = 145

    col_weights = [max(0.55, float(column.get("width_weight", 1.0))) for column in columns]
    row_weights = [max(0.55, float(row.get("height_weight", 1.0))) for row in rows]

    col_widths = [round(base_col_width * weight) for weight in col_weights]
    row_heights = [round(base_row_height * weight) for weight in row_weights]

    width = margin_left + row_header_width + sum(col_widths) + margin_right
    height = title_height + column_header_height + sum(row_heights) + footer_height

    col_left: Dict[str, int] = {}
    col_right: Dict[str, int] = {}
    x = margin_left + row_header_width
    for column, col_width in zip(columns, col_widths):
        column_id = str(column["column_id"])
        col_left[column_id] = x
        col_right[column_id] = x + col_width
        x += col_width

    row_top: Dict[str, int] = {}
    row_bottom: Dict[str, int] = {}
    y = title_height + column_header_height
    for row, row_height in zip(rows, row_heights):
        row_id = str(row["row_id"])
        row_top[row_id] = y
        row_bottom[row_id] = y + row_height
        y += row_height

    col_index = {str(item["column_id"]): index for index, item in enumerate(columns)}
    row_index = {str(item["row_id"]): index for index, item in enumerate(rows)}

    groups: Dict[Tuple[str, str, str, str], List[Dict[str, Any]]] = {}
    for node in nodes:
        column_start = str(node.get("column_start") or node.get("column_id") or "")
        column_end = str(node.get("column_end") or column_start)
        row_start = str(node.get("row_start") or node.get("row_id") or "")
        row_end = str(node.get("row_end") or row_start)
        if column_start not in col_index or column_end not in col_index:
            continue
        if row_start not in row_index or row_end not in row_index:
            continue
        key = (column_start, column_end, row_start, row_end)
        groups.setdefault(key, []).append(node)

    node_boxes: Dict[str, Tuple[int, int, int, int]] = {}
    node_records: List[Dict[str, Any]] = []

    for key, group_nodes in groups.items():
        column_start, column_end, row_start, row_end = key
        c1, c2 = sorted((col_index[column_start], col_index[column_end]))
        r1, r2 = sorted((row_index[row_start], row_index[row_end]))
        left = col_left[str(columns[c1]["column_id"])]
        right = col_right[str(columns[c2]["column_id"])]
        top = row_top[str(rows[r1]["row_id"])]
        bottom = row_bottom[str(rows[r2]["row_id"])]

        group_nodes = sorted(
            group_nodes,
            key=lambda node: (int(node.get("order_in_cell", 9999)), str(node.get("node_id", ""))),
        )
        count = len(group_nodes)

        for index, node in enumerate(group_nodes):
            role = str(node.get("node_role", "process"))
            padding_x = 13
            padding_y = 18
            available_left = left + padding_x
            available_right = right - padding_x
            available_top = top + padding_y
            available_bottom = bottom - padding_y

            if role in {"vertical_bar", "merge_bar", "distribution_bar"}:
                bar_width = max(58, min(95, round((available_right - available_left) * 0.48)))
                center_x = (available_left + available_right) // 2
                box = (
                    center_x - bar_width // 2,
                    available_top,
                    center_x + bar_width // 2,
                    available_bottom,
                )
            elif role in {"container", "external_platform"}:
                box = (available_left, available_top, available_right, available_bottom)
            elif count > 1:
                gap = 10
                total_width = available_right - available_left - gap * (count - 1)
                item_width = max(72, total_width // count)
                x1 = available_left + index * (item_width + gap)
                x2 = min(available_right, x1 + item_width)
                height_ratio = max(0.35, min(1.0, float(node.get("height_ratio", 0.68))))
                target_height = round((available_bottom - available_top) * height_ratio)
                center_y = (available_top + available_bottom) // 2
                box = (x1, center_y - target_height // 2, x2, center_y + target_height // 2)
            else:
                width_ratio = max(0.35, min(1.0, float(node.get("width_ratio", 0.82))))
                height_ratio = max(0.30, min(1.0, float(node.get("height_ratio", 0.60))))
                target_width = round((available_right - available_left) * width_ratio)
                target_height = round((available_bottom - available_top) * height_ratio)
                center_x = (available_left + available_right) // 2
                center_y = (available_top + available_bottom) // 2
                box = (
                    center_x - target_width // 2,
                    center_y - target_height // 2,
                    center_x + target_width // 2,
                    center_y + target_height // 2,
                )

            node_id = str(node.get("node_id", f"N{len(node_records)+1:03d}"))
            node_boxes[node_id] = box
            node_records.append({**node, "node_id": node_id, "box": box})

    return {
        "width": width,
        "height": height,
        "margin_left": margin_left,
        "row_header_width": row_header_width,
        "title_height": title_height,
        "column_header_height": column_header_height,
        "footer_height": footer_height,
        "columns": columns,
        "rows": rows,
        "col_left": col_left,
        "col_right": col_right,
        "row_top": row_top,
        "row_bottom": row_bottom,
        "node_boxes": node_boxes,
        "nodes": node_records,
        "edges": edges,
        "show_column_guides": bool(data.get("show_column_guides", True)),
        "show_row_guides": bool(data.get("show_row_guides", False)),
        "layout_type": str(data.get("layout_type", "matrix_columnar")),
        "reading_direction": str(data.get("reading_direction", "left_to_right")),
    }


def node_colors(node: Dict[str, Any]) -> Tuple[str, str, str]:
    fill = str(node.get("fill_color") or "#FFFFFF")
    border = str(node.get("border_color") or "#1565C0")
    text = str(node.get("text_color") or "#0D2B45")
    role = str(node.get("node_role", "process"))
    if role in {"vertical_bar", "merge_bar", "distribution_bar"} and "fill_color" not in node:
        fill, border, text = "#0D57B7", "#0D57B7", "#FFFFFF"
    return fill, border, text


def edge_path(
    source_box: Tuple[int, int, int, int],
    target_box: Tuple[int, int, int, int],
    edge: Dict[str, Any],
) -> List[Tuple[float, float]]:
    sx1, sy1, sx2, sy2 = source_box
    tx1, ty1, tx2, ty2 = target_box
    source_center = ((sx1 + sx2) / 2, (sy1 + sy2) / 2)
    target_center = ((tx1 + tx2) / 2, (ty1 + ty2) / 2)

    route = str(edge.get("route", "orthogonal"))
    if route == "straight":
        return [source_center, target_center]

    if tx1 >= sx2:
        start = (sx2, source_center[1])
        target_y = source_center[1] if ty1 <= source_center[1] <= ty2 else target_center[1]
        end = (tx1, target_y)
        mid_x = float(edge.get("mid_x", (start[0] + end[0]) / 2))
        return [start, (mid_x, start[1]), (mid_x, end[1]), end]

    if sx1 >= tx2:
        start = (sx1, source_center[1])
        target_y = source_center[1] if ty1 <= source_center[1] <= ty2 else target_center[1]
        end = (tx2, target_y)
        mid_x = float(edge.get("mid_x", (start[0] + end[0]) / 2))
        return [start, (mid_x, start[1]), (mid_x, end[1]), end]

    if ty1 >= sy2:
        start = (source_center[0], sy2)
        end = (target_center[0], ty1)
        mid_y = float(edge.get("mid_y", (start[1] + end[1]) / 2))
        return [start, (start[0], mid_y), (end[0], mid_y), end]

    start = (source_center[0], sy1)
    end = (target_center[0], ty2)
    mid_y = float(edge.get("mid_y", (start[1] + end[1]) / 2))
    return [start, (start[0], mid_y), (end[0], mid_y), end]


def arrow_triangle(points: List[Tuple[float, float]], size: float = 11) -> List[Tuple[float, float]]:
    if len(points) < 2:
        return []
    start, end = points[-2], points[-1]
    angle = math.atan2(end[1] - start[1], end[0] - start[0])
    return [
        end,
        (
            end[0] - size * math.cos(angle - math.pi / 6),
            end[1] - size * math.sin(angle - math.pi / 6),
        ),
        (
            end[0] - size * math.cos(angle + math.pi / 6),
            end[1] - size * math.sin(angle + math.pi / 6),
        ),
    ]


def draw_dashed_vertical(
    draw: ImageDraw.ImageDraw,
    x: int,
    y1: int,
    y2: int,
    fill: str,
    dash: int = 9,
    gap: int = 7,
) -> None:
    y = y1
    while y < y2:
        draw.line((x, y, x, min(y + dash, y2)), fill=fill, width=2)
        y += dash + gap


def render_png(
    figure: Dict[str, Any],
    layout: Dict[str, Any],
    output_path: Path,
) -> None:
    width, height = layout["width"], layout["height"]
    image = Image.new("RGB", (width, height), "#FFFFFF")
    draw = ImageDraw.Draw(image)

    title_font = find_font(32, bold=True)
    subtitle_font = find_font(16)
    header_font = find_font(19, bold=True)
    row_font = find_font(19, bold=True)
    node_id_font = find_font(12, bold=True)
    node_font = find_font(16)
    member_font = find_font(14)
    small_font = find_font(13)

    title = clean_text(figure.get("display_name") or figure.get("figure_id"))
    draw.text((55, 27), title, fill="#102027", font=title_font)
    draw.text(
        (width - 55, 38),
        "结构保真重绘（网格级）",
        fill="#455A64",
        font=subtitle_font,
        anchor="ra",
    )

    header_top = layout["title_height"]
    header_bottom = header_top + layout["column_header_height"]

    for index, column in enumerate(layout["columns"]):
        column_id = str(column["column_id"])
        left = layout["col_left"][column_id]
        right = layout["col_right"][column_id]
        color = str(column.get("fill_color") or DEFAULT_HEADER_COLORS[index % len(DEFAULT_HEADER_COLORS)])
        draw.rounded_rectangle(
            (left + 7, header_top + 10, right - 7, header_bottom - 14),
            radius=12,
            fill=color,
            outline=color,
        )
        lines = text_lines(str(column.get("title", column_id)), 8, 3)
        total = len(lines) * 24
        y = header_top + (layout["column_header_height"] - total) / 2 - 2
        for line in lines:
            bbox = draw.textbbox((0, 0), line, font=header_font)
            draw.text(
                ((left + right - (bbox[2] - bbox[0])) / 2, y),
                line,
                fill="#FFFFFF",
                font=header_font,
            )
            y += 24
        if layout["show_column_guides"]:
            draw_dashed_vertical(
                draw,
                (left + right) // 2,
                header_bottom - 4,
                height - layout["footer_height"],
                "#9EC1E6",
            )

    body_top = header_bottom
    body_bottom = height - layout["footer_height"]

    for row in layout["rows"]:
        row_id = str(row["row_id"])
        top = layout["row_top"][row_id]
        bottom = layout["row_bottom"][row_id]
        if layout["show_row_guides"]:
            draw.line(
                (layout["margin_left"], bottom, width - 55, bottom),
                fill="#E0E6EC",
                width=1,
            )
        fill = str(row.get("fill_color") or "#0D57B7")
        x1 = layout["margin_left"]
        x2 = x1 + layout["row_header_width"] - 16
        draw.rounded_rectangle(
            (x1, top + 20, x2, bottom - 20),
            radius=11,
            fill=fill,
            outline=fill,
        )
        lines = text_lines(str(row.get("title", row_id)), 9, 3)
        total = len(lines) * 25
        y = top + (bottom - top - total) / 2
        for line in lines:
            bbox = draw.textbbox((0, 0), line, font=row_font)
            draw.text(
                (x1 + (x2 - x1 - (bbox[2] - bbox[0])) / 2, y),
                line,
                fill="#FFFFFF",
                font=row_font,
            )
            y += 25

    for node in layout["nodes"]:
        x1, y1, x2, y2 = node["box"]
        fill, border, text_color = node_colors(node)
        role = str(node.get("node_role", "process"))
        radius = 9 if role not in {"vertical_bar", "merge_bar", "distribution_bar"} else 5
        draw.rounded_rectangle(
            (x1, y1, x2, y2),
            radius=radius,
            fill=fill,
            outline=border,
            width=2,
        )
        node_id = str(node["node_id"])
        draw.text((x1 + 7, y1 + 5), node_id, fill=text_color, font=node_id_font)

        label = clean_text(node.get("label", node_id))
        members = node.get("members") if isinstance(node.get("members"), list) else []
        max_chars = max(4, int((x2 - x1) / 17))
        max_lines = 4 if role in {"container", "external_platform"} else 3
        lines = text_lines(label, max_chars, max_lines)
        line_height = 21
        text_y = y1 + 28
        for line in lines:
            bbox = draw.textbbox((0, 0), line, font=node_font)
            draw.text(
                (x1 + (x2 - x1 - (bbox[2] - bbox[0])) / 2, text_y),
                line,
                fill=text_color,
                font=node_font,
            )
            text_y += line_height

        if members and y2 - text_y > 28:
            text_y += 5
            for member in members[:6]:
                member_text = "• " + clean_text(member)
                for line in text_lines(member_text, max_chars, 2):
                    draw.text((x1 + 10, text_y), line, fill=text_color, font=member_font)
                    text_y += 18
                    if text_y > y2 - 20:
                        break
                if text_y > y2 - 20:
                    break

    for edge in layout["edges"]:
        source_box = layout["node_boxes"].get(str(edge.get("source", "")))
        target_box = layout["node_boxes"].get(str(edge.get("target", "")))
        if not source_box or not target_box:
            continue
        points = edge_path(source_box, target_box, edge)
        flow_type = str(edge.get("flow_type", "unknown"))
        color = FLOW_COLORS.get(flow_type, FLOW_COLORS["unknown"])
        draw.line(points, fill=color, width=3, joint="curve")
        if edge.get("arrow", True):
            triangle = arrow_triangle(points)
            if triangle:
                draw.polygon(triangle, fill=color)

        label = clean_text(edge.get("label"))
        if label:
            mid = points[len(points) // 2]
            bbox = draw.textbbox((0, 0), label, font=small_font)
            box_w = min(190, bbox[2] - bbox[0] + 14)
            draw.rounded_rectangle(
                (mid[0] - box_w / 2, mid[1] - 15, mid[0] + box_w / 2, mid[1] + 15),
                radius=5,
                fill="#FFFFFF",
                outline=color,
            )
            draw.text(
                (mid[0], mid[1]),
                label[:16],
                fill=color,
                font=small_font,
                anchor="mm",
            )

    footer_y = body_bottom + 20
    draw.line((55, footer_y, width - 55, footer_y), fill="#CFD8DC", width=2)
    draw.text(
        (55, footer_y + 18),
        "结构保真重绘：保留原图的列序、行序、并行链路和跨行汇聚；不承诺像素级复刻。",
        fill="#607D8B",
        font=small_font,
    )
    draw.text(
        (width - 55, footer_y + 18),
        f"{len(layout['columns'])}列 · {len(layout['rows'])}行 · "
        f"{len(layout['nodes'])}节点 · {len(layout['edges'])}关系",
        fill="#607D8B",
        font=small_font,
        anchor="ra",
    )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    image.save(output_path, format="PNG", optimize=True)


def svg_text(
    x: float,
    y: float,
    lines: List[str],
    size: int,
    fill: str,
    anchor: str = "middle",
    weight: str = "normal",
    line_height: Optional[int] = None,
) -> str:
    line_height = line_height or round(size * 1.35)
    spans = []
    for index, line in enumerate(lines):
        dy = 0 if index == 0 else line_height
        spans.append(f'<tspan x="{x:.1f}" dy="{dy}">{xml_escape(line)}</tspan>')
    return (
        f'<text x="{x:.1f}" y="{y:.1f}" text-anchor="{anchor}" '
        f'font-family="{DEFAULT_FONT_FAMILIES}" font-size="{size}" '
        f'font-weight="{weight}" fill="{fill}">'
        + "".join(spans)
        + "</text>"
    )


def render_svg(
    figure: Dict[str, Any],
    layout: Dict[str, Any],
    output_path: Path,
    metadata: Dict[str, Any],
) -> None:
    width, height = layout["width"], layout["height"]
    elements: List[str] = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
        f'viewBox="0 0 {width} {height}">',
        "<defs>",
    ]
    for flow_type, color in FLOW_COLORS.items():
        elements.append(
            f'<marker id="layout-arrow-{flow_type}" markerWidth="10" markerHeight="10" '
            f'refX="9" refY="3" orient="auto" markerUnits="strokeWidth">'
            f'<path d="M0,0 L0,6 L9,3 z" fill="{color}"/></marker>'
        )
    elements += [
        "</defs>",
        f"<metadata>{xml_escape(json.dumps(metadata, ensure_ascii=False))}</metadata>",
        '<rect x="0" y="0" width="100%" height="100%" fill="#FFFFFF"/>',
        svg_text(
            55,
            55,
            [clean_text(figure.get("display_name") or figure.get("figure_id"))],
            32,
            "#102027",
            anchor="start",
            weight="bold",
        ),
        svg_text(
            width - 55,
            55,
            ["结构保真重绘（网格级）"],
            16,
            "#455A64",
            anchor="end",
        ),
    ]

    header_top = layout["title_height"]
    header_bottom = header_top + layout["column_header_height"]

    for index, column in enumerate(layout["columns"]):
        column_id = str(column["column_id"])
        left = layout["col_left"][column_id]
        right = layout["col_right"][column_id]
        color = str(column.get("fill_color") or DEFAULT_HEADER_COLORS[index % len(DEFAULT_HEADER_COLORS)])
        elements.append(
            f'<rect x="{left+7}" y="{header_top+10}" width="{right-left-14}" '
            f'height="{layout["column_header_height"]-24}" rx="12" fill="{color}"/>'
        )
        lines = text_lines(str(column.get("title", column_id)), 8, 3)
        y = header_top + 41 - (len(lines) - 1) * 10
        elements.append(
            svg_text((left + right) / 2, y, lines, 19, "#FFFFFF", weight="bold", line_height=24)
        )
        if layout["show_column_guides"]:
            elements.append(
                f'<line x1="{(left+right)/2:.1f}" y1="{header_bottom-4}" '
                f'x2="{(left+right)/2:.1f}" y2="{height-layout["footer_height"]}" '
                f'stroke="#9EC1E6" stroke-width="2" stroke-dasharray="9 7"/>'
            )

    for row in layout["rows"]:
        row_id = str(row["row_id"])
        top = layout["row_top"][row_id]
        bottom = layout["row_bottom"][row_id]
        fill = str(row.get("fill_color") or "#0D57B7")
        x1 = layout["margin_left"]
        x2 = x1 + layout["row_header_width"] - 16
        elements.append(
            f'<rect x="{x1}" y="{top+20}" width="{x2-x1}" height="{bottom-top-40}" '
            f'rx="11" fill="{fill}"/>'
        )
        lines = text_lines(str(row.get("title", row_id)), 9, 3)
        y = (top + bottom) / 2 - (len(lines) - 1) * 11
        elements.append(svg_text((x1+x2)/2, y, lines, 19, "#FFFFFF", weight="bold", line_height=25))
        if layout["show_row_guides"]:
            elements.append(
                f'<line x1="{layout["margin_left"]}" y1="{bottom}" x2="{width-55}" '
                f'y2="{bottom}" stroke="#E0E6EC"/>'
            )

    for node in layout["nodes"]:
        x1, y1, x2, y2 = node["box"]
        fill, border, text_color = node_colors(node)
        role = str(node.get("node_role", "process"))
        radius = 9 if role not in {"vertical_bar", "merge_bar", "distribution_bar"} else 5
        elements.append(
            f'<rect x="{x1}" y="{y1}" width="{x2-x1}" height="{y2-y1}" '
            f'rx="{radius}" fill="{fill}" stroke="{border}" stroke-width="2"/>'
        )
        elements.append(svg_text(x1+7, y1+18, [str(node["node_id"])], 12, text_color, anchor="start", weight="bold"))
        max_chars = max(4, int((x2-x1)/17))
        lines = text_lines(str(node.get("label", node["node_id"])), max_chars, 4)
        y = y1 + 42 - (len(lines)-1)*9
        elements.append(svg_text((x1+x2)/2, y, lines, 16, text_color, line_height=21))
        members = node.get("members") if isinstance(node.get("members"), list) else []
        member_y = y + len(lines)*21 + 8
        for member in members[:6]:
            if member_y > y2 - 16:
                break
            elements.append(svg_text(x1+10, member_y, ["• " + clean_text(member)], 13, text_color, anchor="start"))
            member_y += 18

    for edge in layout["edges"]:
        source_box = layout["node_boxes"].get(str(edge.get("source", "")))
        target_box = layout["node_boxes"].get(str(edge.get("target", "")))
        if not source_box or not target_box:
            continue
        points = edge_path(source_box, target_box, edge)
        flow_type = str(edge.get("flow_type", "unknown"))
        if flow_type not in FLOW_COLORS:
            flow_type = "unknown"
        color = FLOW_COLORS[flow_type]
        point_string = " ".join(f"{x:.1f},{y:.1f}" for x, y in points)
        marker = f' marker-end="url(#layout-arrow-{flow_type})"' if edge.get("arrow", True) else ""
        elements.append(
            f'<polyline points="{point_string}" fill="none" stroke="{color}" '
            f'stroke-width="3" stroke-linejoin="round"{marker}/>'
        )
        label = clean_text(edge.get("label"))
        if label:
            mid = points[len(points)//2]
            elements.append(
                f'<rect x="{mid[0]-75}" y="{mid[1]-15}" width="150" height="30" '
                f'rx="5" fill="#FFFFFF" stroke="{color}"/>'
            )
            elements.append(svg_text(mid[0], mid[1]+5, [label[:16]], 13, color))

    footer_y = height - layout["footer_height"] + 20
    elements.append(
        f'<line x1="55" y1="{footer_y}" x2="{width-55}" y2="{footer_y}" '
        f'stroke="#CFD8DC" stroke-width="2"/>'
    )
    elements.append(
        svg_text(
            55,
            footer_y+27,
            ["结构保真重绘：保留原图的列序、行序、并行链路和跨行汇聚；不承诺像素级复刻。"],
            13,
            "#607D8B",
            anchor="start",
        )
    )
    elements.append(
        svg_text(
            width-55,
            footer_y+27,
            [
                f"{len(layout['columns'])}列 · {len(layout['rows'])}行 · "
                f"{len(layout['nodes'])}节点 · {len(layout['edges'])}关系"
            ],
            13,
            "#607D8B",
            anchor="end",
        )
    )
    elements.append("</svg>")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(elements), encoding="utf-8")


def generate_layout_outputs(
    figure: Dict[str, Any],
    output_dir: Path,
    stem: str,
    metadata: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    if not is_enabled(figure):
        return None

    layout = calculate_grid(figure)
    svg_rel = f"assets/ai_reconstructed/{stem}_layout.svg"
    png_rel = f"assets/ai_reconstructed/{stem}_layout.png"
    svg_path = output_dir / svg_rel
    png_path = output_dir / png_rel

    render_svg(figure, layout, svg_path, {**metadata, "render_mode": "layout_preserving_reconstruction"})
    render_png(figure, layout, png_path)

    return {
        "layout_svg_path": svg_rel,
        "layout_png_path": png_rel,
        "layout_width": layout["width"],
        "layout_height": layout["height"],
        "layout_column_count": len(layout["columns"]),
        "layout_row_count": len(layout["rows"]),
        "layout_node_count": len(layout["nodes"]),
        "layout_edge_count": len(layout["edges"]),
        "layout_type": layout["layout_type"],
        "reading_direction": layout["reading_direction"],
        "layout_fidelity": {
            "preserves_column_order": True,
            "preserves_row_order": True,
            "preserves_parallel_rows": True,
            "preserves_spanning_nodes": True,
            "preserves_orthogonal_routes": True,
            "pixel_exact": False,
        },
    }
