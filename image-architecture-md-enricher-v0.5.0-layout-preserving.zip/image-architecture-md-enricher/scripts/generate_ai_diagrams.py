#!/usr/bin/env python3
"""Generate AI-readable semantic diagrams from standalone analysis Markdown.

The renderer intentionally produces a standardized semantic reconstruction,
not a pixel-level copy of the source image. Text is read from the generated
Markdown, while typed relationships are taken from figure_manifest.json.
"""

from __future__ import annotations

import argparse
import hashlib
import html
import json
import math
import re
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
from xml.sax.saxutils import escape as xml_escape

from PIL import Image, ImageDraw, ImageFont
from layout_preserving_renderer import generate_layout_outputs, is_enabled as layout_preservation_enabled


STREAMING_TYPES = {
    "media_streaming_business_architecture",
    "live_streaming_architecture",
    "vod_architecture",
    "live_vod_converged_architecture",
    "live_ecommerce_architecture",
    "interactive_live_architecture",
    "media_processing_pipeline",
    "streaming_distribution_architecture",
}

ARCHITECTURE_TYPES = {
    "system_architecture",
    "business_architecture",
    "layered_architecture",
    "data_flow",
    "workflow",
    "module_block_diagram",
    "training_pipeline",
    "control_architecture",
    "network_architecture",
    "deployment_architecture",
} | STREAMING_TYPES

FLOW_COLORS = {
    "media_flow": "#1565C0",
    "message_flow": "#7B1FA2",
    "control_flow": "#EF6C00",
    "data_flow": "#00838F",
    "business_flow": "#2E7D32",
    "fund_flow": "#C62828",
    "dependency": "#455A64",
    "unknown": "#616161",
}

LANE_STYLES = {
    "业务参与者": ("#E3F2FD", "#1565C0"),
    "业务场景": ("#E8EAF6", "#3949AB"),
    "业务能力": ("#E0F2F1", "#00796B"),
    "直播媒体链路": ("#FFF3E0", "#EF6C00"),
    "点播媒体链路": ("#E8F5E9", "#2E7D32"),
    "互动链路": ("#F3E5F5", "#7B1FA2"),
    "电商链路": ("#FFEBEE", "#C62828"),
    "关键流向": ("#E0F7FA", "#00838F"),
    "管理与支撑": ("#ECEFF1", "#455A64"),
    "架构模块": ("#E8EAF6", "#3949AB"),
    "关系摘要": ("#FFFDE7", "#9E7700"),
}

DEFAULT_FONT_FAMILIES = "Microsoft YaHei, Noto Sans CJK SC, PingFang SC, SimHei, sans-serif"


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def clean_markdown_text(text: str) -> str:
    text = re.sub(r"!\[[^\]]*\]\([^)]+\)", "", text)
    text = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", text)
    text = re.sub(r"[*_`~]+", "", text)
    text = re.sub(r"<[^>]+>", "", text)
    return re.sub(r"\s+", " ", text).strip()


def remove_existing_ai_content(markdown: str) -> str:
    markdown = re.sub(
        r"\n?<!-- ai-diagram:AI-FIG-\d{3}:start -->.*?<!-- ai-diagram:AI-FIG-\d{3}:end -->\n?",
        "\n",
        markdown,
        flags=re.DOTALL,
    )
    markdown = re.sub(
        r"\n?<!-- ai-resource-index:start -->.*?<!-- ai-resource-index:end -->\n?",
        "\n",
        markdown,
        flags=re.DOTALL,
    )
    return markdown.rstrip() + "\n"


def parse_list_items(body: str) -> List[str]:
    items: List[str] = []
    for line in body.splitlines():
        match = re.match(r"^\s*(?:[-*+]|\d+[.)])\s+(.+?)\s*$", line)
        if match:
            value = clean_markdown_text(match.group(1))
            if value:
                items.append(value)
    if not items:
        paragraphs = [
            clean_markdown_text(part)
            for part in re.split(r"\n\s*\n", body)
            if clean_markdown_text(part)
        ]
        items.extend(paragraphs)
    return items


def parse_figure_blocks(markdown: str) -> Dict[str, Dict[str, Any]]:
    result: Dict[str, Dict[str, Any]] = {}
    pattern = re.compile(
        r"<!-- figure:(FIG-\d{3}):start -->(.*?)<!-- figure:\1:end -->",
        flags=re.DOTALL,
    )
    for match in pattern.finditer(markdown):
        figure_id = match.group(1)
        block = match.group(2).strip()
        title_match = re.search(r"^###\s+(.+?)\s*$", block, flags=re.MULTILINE)
        title = clean_markdown_text(title_match.group(1)) if title_match else figure_id
        section_matches = list(
            re.finditer(r"^####\s+(.+?)\s*$", block, flags=re.MULTILINE)
        )
        sections: Dict[str, Dict[str, Any]] = {}
        for index, section_match in enumerate(section_matches):
            heading = clean_markdown_text(section_match.group(1))
            start = section_match.end()
            end = (
                section_matches[index + 1].start()
                if index + 1 < len(section_matches)
                else len(block)
            )
            body = block[start:end].strip()
            sections[heading] = {
                "body": clean_markdown_text(body),
                "items": parse_list_items(body),
            }
        result[figure_id] = {
            "title": title,
            "raw": block,
            "raw_sha256": sha256_text(block),
            "sections": sections,
        }
    return result


def object_label(item: Any) -> str:
    if isinstance(item, str):
        return clean_markdown_text(item)
    if not isinstance(item, dict):
        return clean_markdown_text(str(item))
    pairs = [
        ("actor", "role"),
        ("component", "action"),
        ("source", "target"),
        ("name", "description"),
        ("label", "role"),
    ]
    for first, second in pairs:
        a = clean_markdown_text(str(item.get(first, "")))
        b = clean_markdown_text(str(item.get(second, "")))
        if a and b:
            if first == "source" and second == "target":
                description = clean_markdown_text(str(item.get("description", "")))
                return f"{a} → {b}" + (f"\n{description}" if description else "")
            return f"{a}\n{b}"
    values: List[str] = []
    for key in [
        "component",
        "action",
        "actor",
        "role",
        "source",
        "target",
        "transport",
        "description",
        "meaning",
    ]:
        value = clean_markdown_text(str(item.get(key, "")))
        if value and value not in values:
            values.append(value)
    return "\n".join(values[:3]) or clean_markdown_text(json.dumps(item, ensure_ascii=False))


def markdown_items(block: Dict[str, Any], section_name: str) -> List[str]:
    section = block.get("sections", {}).get(section_name, {})
    return list(section.get("items", []))


def manifest_items(figure: Dict[str, Any], field: str) -> List[Any]:
    value = figure.get(field)
    return value if isinstance(value, list) else []


def choose_items(
    block: Dict[str, Any],
    section_name: str,
    figure: Dict[str, Any],
    field: str,
) -> List[str]:
    md_items = markdown_items(block, section_name)
    if md_items:
        return md_items
    return [object_label(item) for item in manifest_items(figure, field) if object_label(item)]


def shorten(text: str, limit: int = 90) -> str:
    text = clean_markdown_text(text)
    return text if len(text) <= limit else text[: limit - 1] + "…"


def add_lane(
    lanes: List[Dict[str, Any]],
    title: str,
    items: Iterable[str],
    prefix: str,
    sequential: bool = False,
    flow_type: str = "dependency",
) -> None:
    cleaned = [shorten(item) for item in items if clean_markdown_text(item)]
    if not cleaned:
        return
    nodes = [
        {
            "id": f"{prefix}{index:02d}",
            "label": item,
            "lane": title,
        }
        for index, item in enumerate(cleaned, start=1)
    ]
    edges: List[Dict[str, Any]] = []
    if sequential and len(nodes) > 1:
        for source, target in zip(nodes, nodes[1:]):
            edges.append(
                {
                    "source": source["id"],
                    "target": target["id"],
                    "label": "",
                    "flow_type": flow_type,
                }
            )
    lanes.append({"title": title, "nodes": nodes, "edges": edges})


def pipeline_labels(items: List[Any]) -> List[str]:
    result: List[str] = []
    for item in items:
        if isinstance(item, dict):
            step = clean_markdown_text(str(item.get("step", "")))
            component = clean_markdown_text(str(item.get("component", "")))
            action = clean_markdown_text(str(item.get("action", "")))
            source = clean_markdown_text(str(item.get("source", "")))
            target = clean_markdown_text(str(item.get("target", "")))
            description = clean_markdown_text(str(item.get("description", "")))
            if component:
                label = component
                if action:
                    label += "\n" + action
            elif source and target:
                label = f"{source} → {target}"
                if description:
                    label += "\n" + description
            else:
                label = object_label(item)
            if step and not label.startswith(step):
                label = f"{step}. {label}"
            result.append(label)
        else:
            result.append(object_label(item))
    return [item for item in result if item]


def build_streaming_model(
    figure: Dict[str, Any],
    block: Dict[str, Any],
) -> Dict[str, Any]:
    lanes: List[Dict[str, Any]] = []
    add_lane(
        lanes,
        "业务参与者",
        choose_items(block, "业务参与者", figure, "business_actors"),
        "A",
    )
    add_lane(
        lanes,
        "业务场景",
        choose_items(block, "业务场景", figure, "business_scenarios"),
        "S",
    )
    add_lane(
        lanes,
        "业务能力",
        choose_items(block, "业务能力", figure, "business_capabilities"),
        "C",
    )
    add_lane(
        lanes,
        "直播媒体链路",
        pipeline_labels(manifest_items(figure, "live_media_pipeline"))
        or markdown_items(block, "直播媒体链路"),
        "L",
        sequential=True,
        flow_type="media_flow",
    )
    add_lane(
        lanes,
        "点播媒体链路",
        pipeline_labels(manifest_items(figure, "vod_media_pipeline"))
        or markdown_items(block, "点播媒体链路"),
        "V",
        sequential=True,
        flow_type="media_flow",
    )
    add_lane(
        lanes,
        "互动链路",
        pipeline_labels(manifest_items(figure, "interaction_pipeline"))
        or markdown_items(block, "互动链路"),
        "I",
        sequential=True,
        flow_type="message_flow",
    )
    add_lane(
        lanes,
        "电商链路",
        pipeline_labels(manifest_items(figure, "commerce_pipeline"))
        or markdown_items(block, "电商链路"),
        "E",
        sequential=True,
        flow_type="business_flow",
    )

    support: List[str] = []
    support.extend(choose_items(block, "管理与支撑能力", figure, "management_capabilities"))
    support.extend(choose_items(block, "存储与分发", figure, "storage_and_distribution"))
    support.extend(choose_items(block, "安全与治理", figure, "security_and_governance"))
    add_lane(lanes, "管理与支撑", support, "P")

    flow_nodes: List[Dict[str, Any]] = []
    flow_edges: List[Dict[str, Any]] = []
    node_index: Dict[str, str] = {}
    for index, flow in enumerate(manifest_items(figure, "business_flows"), start=1):
        if not isinstance(flow, dict):
            continue
        source = clean_markdown_text(str(flow.get("source", "")))
        target = clean_markdown_text(str(flow.get("target", "")))
        if not source or not target:
            continue
        for value in (source, target):
            if value not in node_index:
                node_id = f"F{len(node_index)+1:02d}"
                node_index[value] = node_id
                flow_nodes.append({"id": node_id, "label": value, "lane": "关键流向"})
        flow_edges.append(
            {
                "source": node_index[source],
                "target": node_index[target],
                "label": shorten(str(flow.get("description", "")), 45),
                "flow_type": str(flow.get("flow_type", "unknown")),
            }
        )
    if flow_nodes:
        lanes.append({"title": "关键流向", "nodes": flow_nodes, "edges": flow_edges})

    profile = figure.get("streaming_profile", {})
    subtitle_parts: List[str] = []
    if isinstance(profile, dict):
        mode_labels = {
            "live": "直播",
            "vod": "点播",
            "live_and_vod": "点播与直播融合",
            "unknown": "模式不确定",
        }
        scope_labels = {
            "business": "业务架构",
            "technical": "技术架构",
            "business_and_technical": "业务技术混合架构",
            "unknown": "范围不确定",
        }
        subtitle_parts.append(mode_labels.get(str(profile.get("delivery_mode")), ""))
        subtitle_parts.append(scope_labels.get(str(profile.get("architecture_scope")), ""))
    subtitle = " · ".join(part for part in subtitle_parts if part)

    return {
        "title": block.get("title") or figure.get("display_name") or figure.get("figure_id"),
        "subtitle": subtitle,
        "lanes": lanes,
        "covered_sections": list(block.get("sections", {}).keys()),
    }


def build_general_model(
    figure: Dict[str, Any],
    block: Dict[str, Any],
) -> Dict[str, Any]:
    lanes: List[Dict[str, Any]] = []
    nodes = figure.get("nodes")
    edges = figure.get("edges")
    if isinstance(nodes, list) and nodes:
        grouped: Dict[str, List[Dict[str, str]]] = {}
        id_map: Dict[str, str] = {}
        for index, node in enumerate(nodes, start=1):
            if not isinstance(node, dict):
                continue
            node_id = str(node.get("node_id") or node.get("id") or f"N{index:02d}")
            label = (
                clean_markdown_text(str(node.get("translated_label", "")))
                or clean_markdown_text(str(node.get("label", "")))
                or node_id
            )
            role = clean_markdown_text(str(node.get("role", "")))
            if role:
                label += "\n" + role
            group = (
                clean_markdown_text(str(node.get("group", "")))
                or clean_markdown_text(str(node.get("layer", "")))
                or "架构模块"
            )
            grouped.setdefault(group, []).append(
                {"id": node_id, "label": shorten(label), "lane": group}
            )
            id_map[node_id] = node_id
        edge_records: List[Dict[str, Any]] = []
        if isinstance(edges, list):
            for edge in edges:
                if not isinstance(edge, dict):
                    continue
                source = str(edge.get("source", ""))
                target = str(edge.get("target", ""))
                if source in id_map and target in id_map:
                    edge_records.append(
                        {
                            "source": source,
                            "target": target,
                            "label": shorten(str(edge.get("label") or edge.get("meaning") or ""), 45),
                            "flow_type": str(edge.get("flow_type") or "dependency"),
                        }
                    )
        first = True
        for group, group_nodes in grouped.items():
            lanes.append(
                {
                    "title": group,
                    "nodes": group_nodes,
                    "edges": edge_records if first else [],
                }
            )
            first = False
    else:
        module_items = markdown_items(block, "模块组成")
        if not module_items:
            module_items = [
                object_label(item)
                for item in (
                    figure.get("module_summary")
                    if isinstance(figure.get("module_summary"), list)
                    else [figure.get("module_summary", "")]
                )
                if object_label(item)
            ]
        add_lane(lanes, "架构模块", module_items, "N")
        relation_items = markdown_items(block, "信息流与关系")
        if not relation_items:
            relation_items = [
                object_label(item)
                for item in (
                    figure.get("relationship_summary")
                    if isinstance(figure.get("relationship_summary"), list)
                    else [figure.get("relationship_summary", "")]
                )
                if object_label(item)
            ]
        add_lane(lanes, "关系摘要", relation_items, "R")

    if not lanes:
        summary = (
            block.get("sections", {}).get("架构概述", {}).get("body")
            or figure.get("one_sentence_summary")
            or "暂无可重绘的结构化内容"
        )
        add_lane(lanes, "架构模块", [summary], "N")

    layout = figure.get("layout", {})
    subtitle = clean_markdown_text(str(layout.get("description", ""))) if isinstance(layout, dict) else ""
    return {
        "title": block.get("title") or figure.get("display_name") or figure.get("figure_id"),
        "subtitle": subtitle,
        "lanes": lanes,
        "covered_sections": list(block.get("sections", {}).keys()),
    }


def find_font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates: List[Path] = []
    if sys.platform.startswith("win"):
        base = Path("C:/Windows/Fonts")
        candidates.extend(
            [
                base / ("msyhbd.ttc" if bold else "msyh.ttc"),
                base / ("simhei.ttf" if bold else "simsun.ttc"),
            ]
        )
    elif sys.platform == "darwin":
        candidates.extend(
            [
                Path("/System/Library/Fonts/PingFang.ttc"),
                Path("/System/Library/Fonts/STHeiti Medium.ttc"),
            ]
        )
    else:
        candidates.extend(
            [
                Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc" if bold else "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"),
                Path("/usr/share/fonts/truetype/arphic-gbsn00lp/gbsn00lp.ttf"),
                Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
            ]
        )
    for candidate in candidates:
        if candidate.exists():
            try:
                return ImageFont.truetype(str(candidate), size=size)
            except Exception:
                continue
    return ImageFont.load_default()


def wrap_text_pixels(
    draw: ImageDraw.ImageDraw,
    text: str,
    font: ImageFont.ImageFont,
    max_width: int,
    max_lines: int = 4,
) -> List[str]:
    result: List[str] = []
    for paragraph in text.splitlines() or [""]:
        current = ""
        for char in paragraph:
            trial = current + char
            width = draw.textbbox((0, 0), trial, font=font)[2]
            if current and width > max_width:
                result.append(current)
                current = char
                if len(result) >= max_lines:
                    break
            else:
                current = trial
        if len(result) >= max_lines:
            break
        if current:
            result.append(current)
        if len(result) >= max_lines:
            break
    if len(result) == max_lines and any(text not in "".join(result) for _ in [0]):
        result[-1] = result[-1][:-1] + "…" if result[-1] else "…"
    return result or [""]


def wrap_text_chars(text: str, max_chars: int = 15, max_lines: int = 4) -> List[str]:
    lines: List[str] = []
    for paragraph in text.splitlines() or [""]:
        while paragraph:
            lines.append(paragraph[:max_chars])
            paragraph = paragraph[max_chars:]
            if len(lines) >= max_lines:
                break
        if len(lines) >= max_lines:
            break
    if len(lines) >= max_lines and len("".join(lines)) < len(text.replace("\n", "")):
        lines[-1] = lines[-1][:-1] + "…" if lines[-1] else "…"
    return lines or [""]


def calculate_layout(model: Dict[str, Any]) -> Dict[str, Any]:
    canvas_width = 1800
    margin = 55
    header_height = 130
    lane_label_width = 210
    card_width = 250
    card_height = 92
    gap_x = 28
    gap_y = 24
    content_width = canvas_width - margin * 2 - lane_label_width - 25
    columns = max(1, min(5, int((content_width + gap_x) // (card_width + gap_x))))
    y = header_height
    node_boxes: Dict[str, Tuple[int, int, int, int]] = {}
    lane_layouts: List[Dict[str, Any]] = []
    total_edges = 0

    for lane in model.get("lanes", []):
        nodes = lane.get("nodes", [])
        rows = max(1, math.ceil(len(nodes) / columns))
        lane_height = 42 + rows * card_height + max(0, rows - 1) * gap_y + 32
        lane_record = {
            "title": lane["title"],
            "x": margin,
            "y": y,
            "width": canvas_width - 2 * margin,
            "height": lane_height,
            "nodes": [],
            "edges": list(lane.get("edges", [])),
        }
        content_x = margin + lane_label_width + 25
        node_y0 = y + 42
        for index, node in enumerate(nodes):
            row = index // columns
            col = index % columns
            x1 = content_x + col * (card_width + gap_x)
            y1 = node_y0 + row * (card_height + gap_y)
            box = (x1, y1, x1 + card_width, y1 + card_height)
            node_boxes[node["id"]] = box
            lane_record["nodes"].append({**node, "box": box})
        total_edges += len(lane_record["edges"])
        lane_layouts.append(lane_record)
        y += lane_height + 22

    legend_height = 150
    canvas_height = max(720, y + legend_height)
    return {
        "width": canvas_width,
        "height": canvas_height,
        "margin": margin,
        "header_height": header_height,
        "lane_label_width": lane_label_width,
        "lanes": lane_layouts,
        "node_boxes": node_boxes,
        "edge_count": total_edges,
    }


def lane_style(title: str) -> Tuple[str, str]:
    return LANE_STYLES.get(title, ("#F5F5F5", "#455A64"))


def arrow_points(
    start: Tuple[float, float],
    end: Tuple[float, float],
    size: float = 12,
) -> List[Tuple[float, float]]:
    angle = math.atan2(end[1] - start[1], end[0] - start[0])
    left = (
        end[0] - size * math.cos(angle - math.pi / 6),
        end[1] - size * math.sin(angle - math.pi / 6),
    )
    right = (
        end[0] - size * math.cos(angle + math.pi / 6),
        end[1] - size * math.sin(angle + math.pi / 6),
    )
    return [end, left, right]


def edge_geometry(
    source_box: Tuple[int, int, int, int],
    target_box: Tuple[int, int, int, int],
) -> Tuple[Tuple[float, float], Tuple[float, float]]:
    sx1, sy1, sx2, sy2 = source_box
    tx1, ty1, tx2, ty2 = target_box
    source_center = ((sx1 + sx2) / 2, (sy1 + sy2) / 2)
    target_center = ((tx1 + tx2) / 2, (ty1 + ty2) / 2)
    if abs(target_center[0] - source_center[0]) >= abs(target_center[1] - source_center[1]):
        if target_center[0] >= source_center[0]:
            return (sx2, source_center[1]), (tx1, target_center[1])
        return (sx1, source_center[1]), (tx2, target_center[1])
    if target_center[1] >= source_center[1]:
        return (source_center[0], sy2), (target_center[0], ty1)
    return (source_center[0], sy1), (target_center[0], ty2)


def render_png(
    model: Dict[str, Any],
    layout: Dict[str, Any],
    output_path: Path,
    figure_id: str,
) -> None:
    image = Image.new("RGB", (layout["width"], layout["height"]), "#FFFFFF")
    draw = ImageDraw.Draw(image)
    title_font = find_font(34, bold=True)
    subtitle_font = find_font(19)
    lane_font = find_font(21, bold=True)
    node_id_font = find_font(14, bold=True)
    node_font = find_font(17)
    small_font = find_font(14)
    legend_font = find_font(15)

    draw.text((55, 34), model["title"], fill="#102027", font=title_font)
    if model.get("subtitle"):
        draw.text((55, 83), model["subtitle"], fill="#455A64", font=subtitle_font)
    draw.text(
        (layout["width"] - 350, 42),
        f"{figure_id} · AI语义重绘",
        fill="#455A64",
        font=subtitle_font,
    )

    for lane in layout["lanes"]:
        fill, accent = lane_style(lane["title"])
        x, y, width, height = lane["x"], lane["y"], lane["width"], lane["height"]
        draw.rounded_rectangle(
            (x, y, x + width, y + height),
            radius=16,
            fill=fill,
            outline=accent,
            width=2,
        )
        draw.rounded_rectangle(
            (x, y, x + layout["lane_label_width"], y + height),
            radius=16,
            fill=accent,
            outline=accent,
        )
        title_lines = wrap_text_pixels(
            draw, lane["title"], lane_font, layout["lane_label_width"] - 30, max_lines=3
        )
        total_h = len(title_lines) * 28
        ty = y + (height - total_h) / 2
        for line in title_lines:
            bbox = draw.textbbox((0, 0), line, font=lane_font)
            tw = bbox[2] - bbox[0]
            draw.text(
                (x + (layout["lane_label_width"] - tw) / 2, ty),
                line,
                fill="#FFFFFF",
                font=lane_font,
            )
            ty += 28

        for node in lane["nodes"]:
            x1, y1, x2, y2 = node["box"]
            draw.rounded_rectangle(
                (x1, y1, x2, y2),
                radius=12,
                fill="#FFFFFF",
                outline=accent,
                width=2,
            )
            draw.text((x1 + 10, y1 + 8), node["id"], fill=accent, font=node_id_font)
            lines = wrap_text_pixels(
                draw, node["label"], node_font, x2 - x1 - 22, max_lines=3
            )
            line_height = 23
            start_y = y1 + 29 + max(0, (y2 - y1 - 34 - len(lines) * line_height) / 2)
            for line in lines:
                bbox = draw.textbbox((0, 0), line, font=node_font)
                tw = bbox[2] - bbox[0]
                draw.text(
                    (x1 + (x2 - x1 - tw) / 2, start_y),
                    line,
                    fill="#102027",
                    font=node_font,
                )
                start_y += line_height

    for lane in layout["lanes"]:
        for edge in lane["edges"]:
            source_box = layout["node_boxes"].get(edge["source"])
            target_box = layout["node_boxes"].get(edge["target"])
            if not source_box or not target_box:
                continue
            start, end = edge_geometry(source_box, target_box)
            flow_type = edge.get("flow_type", "unknown")
            color = FLOW_COLORS.get(flow_type, FLOW_COLORS["unknown"])
            draw.line((start, end), fill=color, width=4)
            draw.polygon(arrow_points(start, end, 14), fill=color)
            label = clean_markdown_text(str(edge.get("label", "")))
            if label:
                mx, my = (start[0] + end[0]) / 2, (start[1] + end[1]) / 2
                lines = wrap_text_pixels(draw, label, small_font, 150, max_lines=2)
                label_w = max(draw.textbbox((0, 0), line, font=small_font)[2] for line in lines)
                label_h = len(lines) * 18
                draw.rounded_rectangle(
                    (
                        mx - label_w / 2 - 6,
                        my - label_h / 2 - 4,
                        mx + label_w / 2 + 6,
                        my + label_h / 2 + 4,
                    ),
                    radius=5,
                    fill="#FFFFFF",
                    outline=color,
                )
                ly = my - label_h / 2
                for line in lines:
                    bbox = draw.textbbox((0, 0), line, font=small_font)
                    tw = bbox[2] - bbox[0]
                    draw.text((mx - tw / 2, ly), line, fill=color, font=small_font)
                    ly += 18

    legend_y = layout["height"] - 120
    draw.line((55, legend_y - 20, layout["width"] - 55, legend_y - 20), fill="#CFD8DC", width=2)
    draw.text((55, legend_y), "流类型图例", fill="#263238", font=lane_font)
    x = 200
    for flow_type, color in FLOW_COLORS.items():
        label_map = {
            "media_flow": "媒体流",
            "message_flow": "消息流",
            "control_flow": "控制流",
            "data_flow": "数据流",
            "business_flow": "业务流",
            "fund_flow": "资金流",
            "dependency": "依赖关系",
            "unknown": "未确定",
        }
        draw.line((x, legend_y + 15, x + 38, legend_y + 15), fill=color, width=4)
        draw.polygon(
            arrow_points((x, legend_y + 15), (x + 38, legend_y + 15), 10),
            fill=color,
        )
        draw.text(
            (x + 48, legend_y + 3),
            label_map[flow_type],
            fill="#263238",
            font=legend_font,
        )
        x += 185
        if x > layout["width"] - 210:
            x = 200
            legend_y += 34
    draw.text(
        (55, layout["height"] - 34),
        "语义重绘：高对比度、显式节点编号、标准箭头与分层；不是原图像素复刻。",
        fill="#607D8B",
        font=small_font,
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    image.save(output_path, format="PNG", optimize=True)


def svg_text(
    x: float,
    y: float,
    lines: List[str],
    font_size: int,
    fill: str,
    anchor: str = "middle",
    weight: str = "normal",
    line_height: Optional[int] = None,
) -> str:
    line_height = line_height or int(font_size * 1.35)
    tspans = []
    for index, line in enumerate(lines):
        dy = 0 if index == 0 else line_height
        tspans.append(
            f'<tspan x="{x:.1f}" dy="{dy}">{xml_escape(line)}</tspan>'
        )
    return (
        f'<text x="{x:.1f}" y="{y:.1f}" text-anchor="{anchor}" '
        f'font-family="{DEFAULT_FONT_FAMILIES}" font-size="{font_size}" '
        f'font-weight="{weight}" fill="{fill}">'
        + "".join(tspans)
        + "</text>"
    )


def render_svg(
    model: Dict[str, Any],
    layout: Dict[str, Any],
    output_path: Path,
    figure_id: str,
    metadata: Dict[str, Any],
) -> None:
    width, height = layout["width"], layout["height"]
    elements: List[str] = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        "<defs>",
    ]
    for flow_type, color in FLOW_COLORS.items():
        elements.append(
            f'<marker id="arrow-{flow_type}" markerWidth="10" markerHeight="10" '
            f'refX="9" refY="3" orient="auto" markerUnits="strokeWidth">'
            f'<path d="M0,0 L0,6 L9,3 z" fill="{color}"/></marker>'
        )
    elements.extend(
        [
            "</defs>",
            f"<metadata>{xml_escape(json.dumps(metadata, ensure_ascii=False))}</metadata>",
            '<rect x="0" y="0" width="100%" height="100%" fill="#FFFFFF"/>',
            svg_text(55, 60, [model["title"]], 34, "#102027", anchor="start", weight="bold"),
        ]
    )
    if model.get("subtitle"):
        elements.append(
            svg_text(55, 98, [model["subtitle"]], 19, "#455A64", anchor="start")
        )
    elements.append(
        svg_text(width - 55, 62, [f"{figure_id} · AI语义重绘"], 19, "#455A64", anchor="end")
    )

    for lane in layout["lanes"]:
        fill, accent = lane_style(lane["title"])
        x, y, lane_width, lane_height = lane["x"], lane["y"], lane["width"], lane["height"]
        elements.append(
            f'<rect x="{x}" y="{y}" width="{lane_width}" height="{lane_height}" '
            f'rx="16" fill="{fill}" stroke="{accent}" stroke-width="2"/>'
        )
        elements.append(
            f'<rect x="{x}" y="{y}" width="{layout["lane_label_width"]}" '
            f'height="{lane_height}" rx="16" fill="{accent}"/>'
        )
        lane_lines = wrap_text_chars(lane["title"], 8, 3)
        lane_y = y + lane_height / 2 - ((len(lane_lines) - 1) * 14)
        elements.append(
            svg_text(
                x + layout["lane_label_width"] / 2,
                lane_y,
                lane_lines,
                21,
                "#FFFFFF",
                weight="bold",
                line_height=28,
            )
        )
        for node in lane["nodes"]:
            x1, y1, x2, y2 = node["box"]
            elements.append(
                f'<rect x="{x1}" y="{y1}" width="{x2-x1}" height="{y2-y1}" '
                f'rx="12" fill="#FFFFFF" stroke="{accent}" stroke-width="2"/>'
            )
            elements.append(
                svg_text(x1 + 10, y1 + 21, [node["id"]], 14, accent, anchor="start", weight="bold")
            )
            lines = wrap_text_chars(node["label"], 15, 3)
            start_y = y1 + 48 - ((len(lines) - 1) * 10)
            elements.append(
                svg_text(
                    (x1 + x2) / 2,
                    start_y,
                    lines,
                    17,
                    "#102027",
                    line_height=23,
                )
            )

    for lane in layout["lanes"]:
        for edge in lane["edges"]:
            source_box = layout["node_boxes"].get(edge["source"])
            target_box = layout["node_boxes"].get(edge["target"])
            if not source_box or not target_box:
                continue
            start, end = edge_geometry(source_box, target_box)
            flow_type = edge.get("flow_type", "unknown")
            if flow_type not in FLOW_COLORS:
                flow_type = "unknown"
            color = FLOW_COLORS[flow_type]
            elements.append(
                f'<line x1="{start[0]:.1f}" y1="{start[1]:.1f}" '
                f'x2="{end[0]:.1f}" y2="{end[1]:.1f}" '
                f'stroke="{color}" stroke-width="4" '
                f'marker-end="url(#arrow-{flow_type})"/>'
            )
            label = clean_markdown_text(str(edge.get("label", "")))
            if label:
                mx, my = (start[0] + end[0]) / 2, (start[1] + end[1]) / 2
                lines = wrap_text_chars(label, 12, 2)
                box_w = max(100, min(200, max(len(line) for line in lines) * 16 + 18))
                box_h = len(lines) * 19 + 12
                elements.append(
                    f'<rect x="{mx-box_w/2:.1f}" y="{my-box_h/2:.1f}" '
                    f'width="{box_w:.1f}" height="{box_h:.1f}" rx="5" '
                    f'fill="#FFFFFF" stroke="{color}"/>'
                )
                elements.append(
                    svg_text(mx, my - (len(lines)-1)*8 + 5, lines, 14, color, line_height=18)
                )

    legend_y = height - 100
    elements.append(
        f'<line x1="55" y1="{legend_y-28}" x2="{width-55}" y2="{legend_y-28}" '
        f'stroke="#CFD8DC" stroke-width="2"/>'
    )
    elements.append(svg_text(55, legend_y, ["流类型图例"], 21, "#263238", anchor="start", weight="bold"))
    label_map = {
        "media_flow": "媒体流",
        "message_flow": "消息流",
        "control_flow": "控制流",
        "data_flow": "数据流",
        "business_flow": "业务流",
        "fund_flow": "资金流",
        "dependency": "依赖关系",
        "unknown": "未确定",
    }
    x = 200
    for flow_type, color in FLOW_COLORS.items():
        elements.append(
            f'<line x1="{x}" y1="{legend_y-6}" x2="{x+38}" y2="{legend_y-6}" '
            f'stroke="{color}" stroke-width="4" marker-end="url(#arrow-{flow_type})"/>'
        )
        elements.append(
            svg_text(x + 50, legend_y, [label_map[flow_type]], 15, "#263238", anchor="start")
        )
        x += 185
    elements.append(
        svg_text(
            55,
            height - 22,
            ["语义重绘：高对比度、显式节点编号、标准箭头与分层；不是原图像素复刻。"],
            14,
            "#607D8B",
            anchor="start",
        )
    )
    elements.append("</svg>")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(elements), encoding="utf-8")


def inject_ai_blocks(
    markdown: str,
    diagrams: List[Dict[str, Any]],
) -> str:
    text = remove_existing_ai_content(markdown)
    for diagram in diagrams:
        figure_id = diagram["figure_id"]
        diagram_id = diagram["diagram_id"]
        marker = f"<!-- figure:{figure_id}:end -->"
        if marker not in text:
            continue

        parts = [
            f"\n\n<!-- ai-diagram:{diagram_id}:start -->",
            "#### AI标准化重绘图",
            "",
            f"![{diagram['display_name']}—AI语义重绘]({diagram['png_path']})",
            "",
            f"*该图根据 Markdown 文本和结构化关系进行语义标准化。"
            f"SVG版本：`{diagram['svg_path']}`。*",
        ]

        if diagram.get("layout_png_path"):
            parts += [
                "",
                "#### 结构保真重绘图",
                "",
                f"![{diagram['display_name']}—结构保真重绘]({diagram['layout_png_path']})",
                "",
                f"*该图按照 Manifest 中的列、行、跨行节点和连接关系重绘，"
                f"用于保留原图的总体排布与并行/汇聚结构。"
                f"SVG版本：`{diagram['layout_svg_path']}`。*",
            ]

        parts += [f"<!-- ai-diagram:{diagram_id}:end -->", ""]
        text = text.replace(marker, "\n".join(parts) + marker, 1)

    index_lines = [
        "<!-- ai-resource-index:start -->",
        "# AI重绘资源",
        "",
    ]
    for index, diagram in enumerate(diagrams, start=1):
        index_lines += [
            f"{index}. **{diagram['display_name']}**",
            f"   - 重绘编号：{diagram['diagram_id']}",
            f"   - 来源资源：{diagram['figure_id']}",
            f"   - 语义标准化 PNG：`{diagram['png_path']}`",
            f"   - 语义标准化 SVG：`{diagram['svg_path']}`",
        ]
        if diagram.get("layout_png_path"):
            index_lines += [
                f"   - 结构保真 PNG：`{diagram['layout_png_path']}`",
                f"   - 结构保真 SVG：`{diagram['layout_svg_path']}`",
                f"   - 布局规模：{diagram.get('layout_column_count', 0)}列 × "
                f"{diagram.get('layout_row_count', 0)}行",
            ]
        index_lines += [
            f"   - 语义节点数量：{diagram['node_count']}",
            f"   - 语义关系数量：{diagram['edge_count']}",
            "",
        ]
    index_lines.append("<!-- ai-resource-index:end -->")
    return text.rstrip() + "\n\n" + "\n".join(index_lines) + "\n"

def run_generation(
    markdown_path: Path,
    manifest_path: Path,
    output_dir: Path,
    update_markdown: bool = True,
    formats: str = "both",
) -> Dict[str, Any]:
    markdown_path = markdown_path.expanduser().resolve()
    manifest_path = manifest_path.expanduser().resolve()
    output_dir = output_dir.expanduser().resolve()
    if not markdown_path.exists():
        raise FileNotFoundError(f"Markdown not found: {markdown_path}")
    if not manifest_path.exists():
        raise FileNotFoundError(f"Manifest not found: {manifest_path}")

    original_markdown = markdown_path.read_text(encoding="utf-8")
    clean_markdown = remove_existing_ai_content(original_markdown)
    source_hash = sha256_text(clean_markdown)
    blocks = parse_figure_blocks(clean_markdown)
    manifest = load_json(manifest_path)
    figures = [
        figure
        for figure in manifest.get("figures", [])
        if figure.get("retain", True)
        and figure.get("classification") in ARCHITECTURE_TYPES
        and not (
            isinstance(figure.get("ai_redraw"), dict)
            and figure["ai_redraw"].get("enabled") is False
        )
    ]

    assets_dir = output_dir / "assets" / "ai_reconstructed"
    manifests_dir = output_dir / "manifests"
    assets_dir.mkdir(parents=True, exist_ok=True)
    manifests_dir.mkdir(parents=True, exist_ok=True)

    diagrams: List[Dict[str, Any]] = []
    global_warnings: List[str] = []

    for index, figure in enumerate(figures, start=1):
        figure_id = str(figure.get("figure_id", ""))
        block = blocks.get(figure_id)
        if not block:
            global_warnings.append(f"{figure_id} 在 Markdown 中没有可解析的 figure block。")
            continue
        classification = str(figure.get("classification", "unknown"))
        model = (
            build_streaming_model(figure, block)
            if classification in STREAMING_TYPES
            else build_general_model(figure, block)
        )
        layout = calculate_layout(model)
        diagram_id = f"AI-FIG-{index:03d}"
        stem = f"{figure_id.lower().replace('-', '_')}_ai"
        svg_rel = f"assets/ai_reconstructed/{stem}.svg"
        png_rel = f"assets/ai_reconstructed/{stem}.png"
        svg_path = output_dir / svg_rel
        png_path = output_dir / png_rel

        metadata = {
            "diagram_id": diagram_id,
            "figure_id": figure_id,
            "classification": classification,
            "source_markdown_sha256": source_hash,
            "source_section_sha256": block["raw_sha256"],
            "text_source": "generated_markdown",
            "structure_source": "figure_manifest",
            "ai_readability": {
                "high_contrast": True,
                "explicit_node_ids": True,
                "standard_arrow_legend": True,
                "icon_only_nodes": False,
                "gradients": False,
            },
        }
        # The Skill contract requires both formats. Keep the CLI argument only
        # for backward compatibility, but always emit SVG and PNG.
        if formats != "both":
            global_warnings.append(
                f"{figure_id} requested formats={formats}; both SVG and PNG were emitted by policy."
            )
        render_svg(model, layout, svg_path, figure_id, metadata)
        render_png(model, layout, png_path, figure_id)

        layout_result = generate_layout_outputs(
            figure=figure,
            output_dir=output_dir,
            stem=stem,
            metadata=metadata,
        )

        node_count = sum(len(lane.get("nodes", [])) for lane in model.get("lanes", []))
        edge_count = sum(len(lane.get("edges", [])) for lane in model.get("lanes", []))
        diagrams.append(
            {
                "diagram_id": diagram_id,
                "figure_id": figure_id,
                "display_name": str(figure.get("display_name") or model["title"]),
                "classification": classification,
                "render_mode": (
                    "semantic_and_layout_preserving"
                    if layout_result
                    else "semantic_reconstruction"
                ),
                "source_markdown": str(markdown_path),
                "source_markdown_sha256_before_injection": source_hash,
                "source_section_sha256": block["raw_sha256"],
                "text_source": "generated_markdown",
                "structure_source": "figure_manifest",
                "svg_path": svg_rel,
                "png_path": png_rel,
                "width": layout["width"],
                "height": layout["height"],
                "node_count": node_count,
                "edge_count": edge_count,
                "lane_count": len(model.get("lanes", [])),
                "covered_markdown_sections": model.get("covered_sections", []),
                "render_spec": {
                    "title": model["title"],
                    "subtitle": model.get("subtitle", ""),
                    "lanes": model.get("lanes", []),
                },
                "warnings": [],
                "ai_readability": metadata["ai_readability"],
                **(layout_result or {}),
            }
        )

    final_markdown = clean_markdown
    if update_markdown:
        final_markdown = inject_ai_blocks(clean_markdown, diagrams)
        markdown_path.write_text(final_markdown, encoding="utf-8")

    final_hash = sha256_text(final_markdown)
    result = {
        "version": "1.0",
        "source_markdown": str(markdown_path),
        "source_markdown_sha256_before_injection": source_hash,
        "final_markdown_sha256": final_hash,
        "generated_from_standalone_markdown": True,
        "diagrams": diagrams,
        "warnings": global_warnings,
    }
    ai_manifest_path = manifests_dir / "ai_diagram_manifest.json"
    ai_manifest_path.write_text(
        json.dumps(result, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"Created: {ai_manifest_path}")
    print(f"Generated AI-readable diagrams: {len(diagrams)}")
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--markdown", required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument(
        "--formats",
        choices=["both", "svg", "png"],
        default="both",
    )
    parser.add_argument(
        "--no-update-markdown",
        action="store_true",
        help="Generate image files without injecting their references into Markdown.",
    )
    args = parser.parse_args()
    try:
        run_generation(
            markdown_path=Path(args.markdown),
            manifest_path=Path(args.manifest),
            output_dir=Path(args.output_dir),
            update_markdown=not args.no_update_markdown,
            formats=args.formats,
        )
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
