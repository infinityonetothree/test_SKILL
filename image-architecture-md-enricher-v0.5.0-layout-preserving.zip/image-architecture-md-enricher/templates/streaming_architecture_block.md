<!-- figure:{{figure_id}}:start -->
### {{display_name}}

![{{display_name}}]({{asset_path}})

*图 {{figure_number}}：{{caption}}。*

#### 架构定位

{{streaming_profile}}

{{architecture_description}}

#### 业务参与者

{{business_actors}}

#### 业务场景与能力

{{business_scenarios_and_capabilities}}

#### 直播媒体链路

{{live_media_pipeline}}

#### 点播媒体链路

{{vod_media_pipeline}}

#### 互动链路

{{interaction_pipeline}}

#### 业务流与资金流

{{business_flows}}

#### 管理与支撑能力

{{management_capabilities}}

#### 存储、分发与协议

{{storage_distribution_protocols}}

#### 安全与治理

{{security_and_governance}}

#### 视觉编码说明

{{visual_description}}
<!-- figure:{{figure_id}}:end -->
