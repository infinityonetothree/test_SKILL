---
name: image-architecture-md-enricher
description: >
  分析一张或多张架构图、流程图、数据流图、模块框图及其他图片资源，
  保留并描述图片中的布局、背景颜色、模块颜色、视觉分组、节点、箭头、
  层级和信息流。Markdown 输入为可选：未提供 Markdown 时生成独立的
  架构图解析文档；提供 Markdown 时将图片及解析插入相关章节，并在文档
  末尾生成按分类汇总的完整资源列表和校验报告。未提供 Markdown 时，
  在生成独立 Markdown 后继续生成便于 AI 再识别的标准化 SVG 与 PNG 架构图。
---

# Image Architecture Markdown Enricher

## 1. 目标

本 Skill 以图片为唯一必需输入，不依赖 PowerPoint 文件。

支持两种运行模式：

### 模式 A：独立描述模式

输入：

- 一张图片；
- 多张图片；
- 一个包含图片的目录。

不提供 Markdown。

输出：

- 一份完整的 Markdown 图片解析文档；
- 规范命名后的图片资源；
- 图片清单；
- 图片语义分析清单；
- 分类资源汇总；
- 校验报告；
- 根据生成的 Markdown 再生成 AI 可识别的标准化 SVG 和 PNG；
- AI 重绘清单；
- 将重绘图引用回写独立 Markdown。

### 模式 B：Markdown 增强模式

输入：

- 一张或多张图片；
- 一份已有 Markdown 文档。

输出：

- 在已有 Markdown 基础上插入图片及解析文本的增强文档；
- 分类资源汇总；
- 校验报告。

不得覆盖原始图片和原始 Markdown。

## 2. 输入

### 2.1 必需输入

至少提供以下一种图片输入形式：

1. 单张图片文件；
2. 多个图片文件；
3. 一个包含图片的目录。

默认支持：

- `.png`
- `.jpg`
- `.jpeg`
- `.webp`
- `.bmp`
- `.tif`
- `.tiff`

如果输入为 SVG、PDF、PPT 或其他格式，应先转换为普通图片，再使用本 Skill。

### 2.2 可选输入

- 已有 `.md` 文档；
- 输出文档标题；
- 输出语言，默认 `zh-CN`；
- 是否包含装饰性资源，默认 `false`；
- 图片分类自动接受阈值，默认 `0.75`；
- Markdown 插入位置自动接受阈值，默认 `0.75`；
- 是否保留低置信度图片，默认 `true`。

## 3. 输出

推荐输出结构：

```text
output/
├── architecture_description.md
├── assets/
│   ├── architecture/
│   ├── ai_reconstructed/
│   ├── workflow/
│   ├── result/
│   ├── hardware/
│   ├── screenshot/
│   └── other/
├── manifests/
│   ├── image_inventory.json
│   ├── figure_manifest.json
│   ├── ai_diagram_manifest.json
│   └── insertion_manifest.json
└── reports/
    └── validation_report.md
```

在 Markdown 增强模式中，主输出文件可命名为：

```text
summary_enriched.md
```

## 4. 核心原则

1. 图片是唯一必需输入，不能要求用户补充 PPT。
2. Markdown 是可选输入；没有 Markdown 时必须生成可独立阅读的完整文档。
3. 复杂架构图必须同时保留原图引用和文字解析，不能只输出普通摘要。
4. 不能只识别图片文字，还要解析空间布局、背景、颜色、边框、包含关系、箭头和层级。
5. 背景颜色和排版不能在转为文字时丢失。
6. 颜色含义只有在图例、重复使用、附近标签或整体语义支持时才能确定。
7. 无法辨识的文字、模块和关系必须标记为“不确定”或“无法辨识”，不得猜测。
8. 多张图片必须逐张分析，并在文档末尾按分类汇总全部保留资源。
9. 每个保留资源必须有唯一编号，并且在资源分类汇总中恰好出现一次。
10. 如果提供已有 Markdown，应尽量保持原文、标题层级和章节顺序不变。
11. 所有最终图片引用必须使用相对路径。
12. 脚本负责确定性处理；Agent 负责视觉和语义判断。
13. 独立模式下必须在 Markdown 生成后执行 AI 语义重绘，不能只把 Markdown 页面截图。
14. AI 重绘图必须使用高对比度、显式节点编号、标准箭头、固定流类型图例和纯色背景。
15. AI 重绘是语义重构，不得声称其保持了原图的像素位置、品牌图标或全部视觉细节。
16. 对明显采用阶段列、业务行、并行链路、跨行汇聚或纵向容器的图片，必须同时生成结构保真重绘。
17. 结构保真重绘采用网格级近似，不得宣称为像素级复制。

## 5. Agent 与脚本的职责

### 5.1 脚本负责

- 收集单张、多张或目录中的图片；
- 校验图片是否可读取；
- 统一图片方向；
- 复制或转换为标准资源文件；
- 记录尺寸、宽高比、模式和文件哈希；
- 估计边角背景颜色和主要颜色；
- 生成 `image_inventory.json`；
- 根据 `figure_manifest.json` 生成或增强 Markdown；
- 生成资源分类汇总；
- 检查资源路径、重复编号、遗漏和描述完整性；
- 解析独立 Markdown 中每个 figure block；
- 结合 Markdown 文本和 `figure_manifest.json` 重绘标准化架构图；
- 输出 SVG、PNG 和 `ai_diagram_manifest.json`；
- 将 AI 重绘图引用回写独立 Markdown。

### 5.2 Agent 负责

- 查看每张图片；
- 判断图片类型；
- 判断是否为架构类图片；
- 给图片命名；
- 读取可辨识标签；
- 识别模块、层级、箭头和信息流；
- 解释布局、背景和颜色分组；
- 生成图片描述；
- 在有 Markdown 时判断插入章节和位置；
- 对点播与直播图片区分媒体流、消息流、控制流、业务流、数据流和资金流；
- 标记低置信度信息；
- 确认语义重绘没有加入原图和 Markdown 未支持的新模块或关系。

## 6. 资源分类

必须从下列类型中选择：

### 6.1 通用架构与普通资源

- `system_architecture`
- `business_architecture`
- `layered_architecture`
- `data_flow`
- `workflow`
- `module_block_diagram`
- `training_pipeline`
- `control_architecture`
- `network_architecture`
- `deployment_architecture`
- `experimental_result`
- `table`
- `hardware_photo`
- `software_screenshot`
- `formula`
- `decorative`
- `unknown`

### 6.2 点播与直播业务架构

- `media_streaming_business_architecture`：点播、直播或融合视频业务的总体业务架构；
- `live_streaming_architecture`：实时直播采集、推流、处理、分发和播放架构；
- `vod_architecture`：视频上传、存储、处理、分发和按需播放架构；
- `live_vod_converged_architecture`：同时包含点播与直播链路的融合架构；
- `live_ecommerce_architecture`：包含直播、商品、营销、订单、支付和结算的电商直播架构；
- `interactive_live_architecture`：包含弹幕、评论、点赞、礼物、连麦或即时通信的互动直播架构；
- `media_processing_pipeline`：转码、截图、审核、录制、混流、封装等媒体处理流程；
- `streaming_distribution_architecture`：接入节点、调度、CDN、边缘节点和终端播放的分发架构。

架构类资源包括通用架构类型和上述全部点播、直播类型。

当一张图同时表现业务角色、媒体链路和底层技术组件时，优先选择最具体的点直播分类，并在 `streaming_profile.architecture_scope` 中标记为 `business_and_technical`，不要退化为普通 `system_architecture`。

## 6.1 结构保真重绘（方案 C）

当图片具有以下任一特征时，Agent 应启用 `layout_preservation`：

- 顶部存在按顺序排列的阶段标题；
- 左侧存在主会场、分论坛、业务部门等并行行标题；
- 多条处理链路具有相同阶段结构；
- 右侧存在跨多行的汇聚、精选、分发或第三方平台模块；
- 方框的相对位置本身表达业务关系；
- 原图使用大量正交折线、并行线和汇聚线。

方案 C 不使用复杂 CV。Agent 必须在分析图片时人工形成以下结构：

```json
{
  "ai_redraw": {
    "enabled": true,
    "mode": "both",
    "preferred_layout": "matrix_columnar"
  },
  "layout_preservation": {
    "enabled": true,
    "layout_type": "matrix_columnar",
    "reading_direction": "left_to_right",
    "column_headers": [],
    "row_headers": [],
    "grid_nodes": [],
    "grid_edges": [],
    "parallel_groups": [],
    "merge_points": [],
    "distribution_points": []
  }
}
```

### 列和行

`column_headers` 保存原图从左到右的阶段顺序。  
`row_headers` 保存原图从上到下的业务行顺序。

不得为了简化而改变阶段顺序或会场顺序。

### 节点定位

每个 `grid_node` 必须指出其所在列和行：

```json
{
  "node_id": "N01",
  "label": "实体导播台",
  "column_id": "C02",
  "row_id": "R01",
  "node_role": "process"
}
```

跨多行模块使用：

```json
{
  "node_id": "M01",
  "label": "精选12路",
  "column_id": "C06",
  "row_start": "R01",
  "row_end": "R04",
  "node_role": "merge_bar"
}
```

纵向平台容器使用 `container` 或 `external_platform`，并可用 `members`
列出容器内部项目。

### 连接关系

`grid_edges` 必须保留源节点、目标节点、流类型和正交路由：

```json
{
  "edge_id": "E01",
  "source": "N01",
  "target": "N02",
  "flow_type": "media_flow",
  "route": "orthogonal",
  "arrow": true
}
```

方案 C 重点保留：

1. 列序；
2. 行序；
3. 相同业务行的并行结构；
4. 跨行汇聚节点；
5. 汇聚后的精选与分发链路；
6. 底部或侧边补充来源；
7. 第三方平台等大型容器。

无法可靠判断的节点位置或连接应设置 `review_required: true`，不得随意重排。


## 7. 执行流程

### 第一步：准备图片

运行：

```bash
python scripts/prepare_images.py \
  --input "<图片或图片目录>" \
  --output-dir "<输出目录>"
```

可以重复提供 `--input`：

```bash
python scripts/prepare_images.py \
  --input "<图片1>" \
  --input "<图片2>" \
  --input "<图片目录>" \
  --output-dir "<输出目录>"
```

Windows PowerShell 示例：

```powershell
python scripts\prepare_images.py `
  --input "D:\work\architecture.png" `
  --input "D:\work\other_images" `
  --output-dir "D:\work\output"
```

该步骤必须生成：

```text
<输出目录>/
├── assets/
│   └── source/
└── manifests/
    └── image_inventory.json
```

`image_inventory.json` 至少记录：

- 图片编号；
- 原始文件名；
- 原始路径；
- 标准化后的资源路径；
- 宽度和高度；
- 宽高比；
- 色彩模式；
- 文件格式；
- SHA-256；
- 边角背景颜色估计；
- 主要颜色估计；
- 是否包含透明通道；
- 处理警告。

图片编号格式：

```text
IMG-001
IMG-002
```

### 第二步：Agent 逐张查看图片

Agent 必须查看 `image_inventory.json` 中的每一张图片。

不得只根据文件名判断图片内容。

对于每张图片：

1. 判断分类；
2. 判断是否保留；
3. 生成显示名称；
4. 生成简短图注；
5. 生成一句话摘要；
6. 识别主要文字；
7. 分析布局、背景、颜色和视觉分组；
8. 对架构类图片识别节点、连接关系、层级和反馈路径；
9. 确定是否需要人工复核。

### 第三步：生成 `figure_manifest.json`

每张保留图片至少包含：

- `figure_id`
- `image_id`
- `classification`
- `classification_confidence`
- `retain`
- `display_name`
- `asset_path`
- `caption`
- `one_sentence_summary`
- `visual_description`
- `review_required`

架构类图片还必须包含：

- `architecture_description`
- `module_summary`
- `relationship_summary`
- `layout`
- `background`
- `color_semantics`
- `nodes`
- `edges`

点播与直播类图片还必须包含：

- `streaming_profile`
- `business_actors`
- `business_scenarios`
- `business_capabilities`
- `live_media_pipeline`
- `vod_media_pipeline`
- `interaction_pipeline`
- `management_capabilities`
- `storage_and_distribution`
- `business_flows`

按分类填写原则：

- 纯直播图必须填写 `live_media_pipeline`；
- 纯点播图必须填写 `vod_media_pipeline`；
- 点播直播融合图必须同时填写两条媒体链路；
- 互动直播图必须填写 `interaction_pipeline`；
- 电商直播图必须在 `business_flows` 中区分业务流和资金流；
- 仅媒体处理或分发图可以不填写完整业务角色，但必须填写对应处理链路或分发能力。

每张架构类图片还可以配置：

```json
{
  "ai_redraw": {
    "enabled": true,
    "preferred_layout": "auto",
    "include_original_color_semantics": true,
    "max_nodes": 40
  }
}
```

`ai_redraw.enabled` 默认为 `true`。只有明确设为 `false` 时，独立模式才跳过该图的
AI 语义重绘。

如果提供已有 Markdown，还应包含：

- `recommended_markdown_section`
- `insertion_anchor`
- `insertion_confidence`

资源编号格式：

```text
FIG-001
FIG-002
```

不得依赖原 PPT 页码。

### 第四步：解析背景与视觉结构

对每张架构类图片分析：

#### 4.1 背景

记录：

- 主背景颜色；
- 是否有透明背景；
- 是否存在渐变；
- 是否存在多个背景分区；
- 背景分区是否表达层级、阶段或模块边界；
- 背景与前景文字的对比方式。

脚本给出的边角颜色和主要颜色仅作为辅助证据，Agent 必须以图片实际视觉为准。

#### 4.2 总体布局

布局类型从以下值中选择：

- `left_to_right`
- `right_to_left`
- `top_to_bottom`
- `bottom_to_top`
- `layered`
- `radial`
- `cyclic`
- `matrix`
- `swimlane`
- `central_hub`
- `hybrid`
- `unknown`

描述：

- 主要阅读方向；
- 主路径；
- 并行分支；
- 上下层级；
- 中心与外围；
- 输入和输出；
- 正向链路和反馈链路。

#### 4.3 节点

每个主要节点尽量记录：

- 节点编号；
- 原始标签；
- 中文名称；
- 相对位置；
- 形状；
- 填充颜色；
- 边框颜色；
- 文本颜色；
- 所属视觉分组；
- 语义角色；
- 置信度。

#### 4.4 连接关系

每条主要连接尽量记录：

- 源节点；
- 目标节点；
- 方向；
- 线型；
- 箭头类型；
- 边标签；
- 信息流、控制流、反馈流或依赖关系；
- 置信度。

#### 4.5 视觉编码

必须说明：

- 背景及背景分区；
- 模块颜色和视觉分组；
- 实线、虚线、边框和阴影；
- 重点模块如何突出；
- 包含关系和层级；
- 箭头方向和循环；
- 颜色语义是否确定。

颜色含义不明确时，应使用：

> 不同颜色用于区分模块或阶段，但图片未提供足够证据确定每种颜色的具体语义。

### 第五步：识别与解析点播、直播业务架构

#### 5.1 候选图识别

当图片中出现以下两项或更多特征时，将其视为点播或直播架构候选：

- 主播、观众、运营人员、内容生产者或商家；
- 视频上传、采集、编码、推流、拉流或播放；
- 转码、截图、审核、录制、混流或媒体封装；
- 对象存储、媒资库、视频文件或回放内容；
- CDN、边缘节点、调度、分发网络或播放器；
- 直播间、点播、回看、录播或多端播放；
- 弹幕、评论、点赞、礼物、连麦或即时通信；
- 商品、优惠券、下单、支付、退款、佣金或结算。

不得只根据标题中的“直播”或“视频”分类，必须检查图中的角色、链路和组件。

#### 5.2 首要判定

Agent 必须先回答：

1. 这是业务架构、技术架构还是业务技术混合架构？
2. 仅包含直播、仅包含点播，还是点播直播融合？
3. 是否包含互动、电商、审核、运营或数据分析能力？
4. 图的主要阅读方向、主路径和反馈路径是什么？

将结果写入 `streaming_profile`：

```json
{
  "delivery_mode": "live_and_vod",
  "architecture_scope": "business_and_technical",
  "primary_business_scenario": "interactive_video_platform",
  "evidence": ["图中同时出现推流链路、视频上传链路和CDN分发"]
}
```

`delivery_mode` 只能取：

- `live`
- `vod`
- `live_and_vod`
- `unknown`

#### 5.3 分层识别

优先按以下层次理解，不要把全部矩形框平铺成一个模块列表：

1. 用户与终端层；
2. 业务场景层；
3. 应用与产品层；
4. 媒体能力层；
5. 互动能力层；
6. 管理与运营层；
7. 平台服务层；
8. 数据与存储层；
9. 基础设施与分发层。

#### 5.4 业务参与者和能力

识别并说明：

- 主播、观众、内容运营、平台管理员、商家、广告主等参与者；
- 点播内容管理、直播间管理、媒资管理、内容审核、用户权限、互动消息、推荐、计费、结算、监控和数据分析等能力。

#### 5.5 分别恢复各类链路

必须分别恢复可见链路，不能把所有箭头统一称为“数据流”。

**直播媒体链路**通常为：

```text
采集 → 编码 → 推流 → 接入 → 转码/混流/审核 → CDN → 播放器
```

**点播媒体链路**通常为：

```text
上传 → 对象存储/媒资库 → 转码/截图/审核 → 封装 → CDN → 按需播放
```

**互动链路**通常为：

```text
观众操作 → 长连接/即时通信 → 互动服务 → 消息广播 → 主播与观众
```

**电商业务链路**可能为：

```text
商品展示 → 营销活动 → 下单 → 支付 → 履约/退款 → 结算
```

#### 5.6 区分流类型

`business_flows` 中的 `flow_type` 必须从以下类型选择：

- `media_flow`
- `message_flow`
- `control_flow`
- `data_flow`
- `business_flow`
- `fund_flow`
- `unknown`

无法从图中确认方向或语义时，将置信度降低并标记复核，不得自行补齐典型链路。

#### 5.7 协议、安全和治理

当图片明确标注时，记录：

- RTMP、SRT、WebRTC、HLS、DASH、HTTP-FLV 等协议；
- 鉴权、防盗链、内容审核、鉴黄、版权保护、访问控制；
- 监控告警、质量监测、日志分析和容灾。

图中未标注协议时，不得根据经验强行填写。

### 第六步：选择输出模式

#### 6.1 未提供 Markdown

生成独立文档：

```bash
python scripts/build_markdown.py \
  --manifest "<figure_manifest.json>" \
  --output "<architecture_description.md>" \
  --title "<可选文档标题>"
```

独立文档推荐结构：

```markdown
# 架构图解析

## 总体说明

本文件共解析若干张图片。

## 图片解析

### 图片一：名称

原图、图注、架构概述、模块组成、信息流与关系、视觉编码说明。

#### AI标准化重绘图

基于上述 Markdown 与结构化关系生成的标准化图片。

### 图片二：名称

……

# 资源分类汇总

# AI语义重绘资源
```

`build_markdown.py` 在独立模式下默认自动执行 AI 重绘。若要单独执行：

```bash
python scripts/generate_ai_diagrams.py   --markdown "<architecture_description.md>"   --manifest "<figure_manifest.json>"   --output-dir "<输出目录>"
```

必须生成：

```text
assets/ai_reconstructed/
├── fig_001_ai.svg
└── fig_001_ai.png

manifests/
└── ai_diagram_manifest.json
```

#### 6.1.1 AI语义重绘规则

重绘器必须先读取已经生成的 Markdown，而不是直接绕过 Markdown 使用原始图片。
文本来源为 Markdown，节点关系和流类型来源为 `figure_manifest.json`。

输出图必须满足：

1. 纯白或浅色纯背景；
2. 标题、泳道名称、节点编号和节点文字清晰可见；
3. 每个节点必须包含文字，禁止只保留图标；
4. 模块使用统一圆角矩形；
5. 箭头方向明确；
6. 媒体流、消息流、控制流、数据流、业务流和资金流使用固定颜色图例；
7. 不使用渐变、纹理和复杂阴影；
8. SVG 中包含来源 Markdown 哈希和语义元数据；
9. 同时输出 PNG；
10. 不添加原图和 Markdown 未支持的模块、协议或链路；
11. 图下方注明“语义重绘，不是原图像素复刻”。

对于点播与直播架构，优先使用以下泳道：

- 业务参与者；
- 业务场景；
- 业务能力；
- 直播媒体链路；
- 点播媒体链路；
- 互动链路；
- 电商链路；
- 关键流向；
- 管理与支撑。

如果某一类内容不存在，不得为了版面完整而虚构该泳道。

#### 6.2 提供 Markdown

运行：

```bash
python scripts/build_markdown.py \
  --manifest "<figure_manifest.json>" \
  --source-md "<已有 Markdown>" \
  --output "<summary_enriched.md>"
```

必须：

- 不覆盖原始 Markdown；
- 尽量保持原文；
- 将图片插入相关章节；
- 无法匹配时建立“补充架构图解析”小节；
- 在末尾生成资源分类汇总。

### 第七步：Markdown 插入规则

有 Markdown 时，综合考虑：

```text
0.35 × 图片标签与 Markdown 标题相似度
+ 0.30 × 图片描述与 Markdown 段落相似度
+ 0.20 × 图片主要概念与章节关键词相似度
+ 0.10 × 图片输入顺序与 Markdown 章节顺序一致性
+ 0.05 × “如图所示、整体架构、流程如下”等显式引用匹配
```

处理规则：

- `insertion_confidence >= 0.75`：自动插入相关章节；
- `0.55 <= insertion_confidence < 0.75`：插入相关章节末尾，并标记复核；
- `< 0.55`：放入“补充架构图解析”小节，并标记复核。

如提供 `insertion_anchor`，优先插入包含该锚点文本的段落之后。

### 第八步：标准图片解析块

架构类图片：

```markdown
<!-- figure:FIG-001:start -->
### 分层运动控制系统架构

![分层运动控制系统架构](assets/architecture/fig_001_hierarchical_control_architecture.png)

*图 1：任务指令、策略网络、底层控制器与机器人本体形成的闭环架构。*

#### 架构概述

架构整体说明。

#### 模块组成

- 模块一：作用。
- 模块二：作用。

#### 信息流与关系

1. 模块一向模块二传递信息。
2. 模块二生成输出。
3. 状态通过反馈路径返回。

#### 视觉编码说明

- 背景颜色及背景分区。
- 总体排版和阅读方向。
- 模块颜色和视觉分组。
- 箭头、边框、虚线和阴影。
- 层级关系及重点模块。
<!-- figure:FIG-001:end -->
```

非架构类图片可以省略模块和关系小节，但必须保留原图、图注、摘要和视觉说明。

点播与直播类图片必须使用专用结构，并按实际可见内容保留或省略小节：

```markdown
### 点播与直播融合业务架构

![点播与直播融合业务架构](assets/source/img_001.png)

#### 架构定位

说明业务/技术范围、点播或直播模式及主要业务场景。

#### 业务参与者

- 主播：产生直播内容并参与互动。
- 观众：观看内容并发送互动消息。

#### 业务场景与能力

- 直播间管理；
- 点播内容管理；
- 媒资、审核、权限与运营。

#### 直播媒体链路

1. 采集与编码。
2. 推流、接入和媒体处理。
3. CDN分发和终端播放。

#### 点播媒体链路

1. 上传与存储。
2. 转码、截图和审核。
3. CDN缓存和按需播放。

#### 互动链路

说明弹幕、评论、点赞、礼物或连麦消息的传输关系。

#### 业务流与资金流

仅在图中存在商品、订单、支付或结算时填写。

#### 管理与支撑能力

说明内容管理、用户权限、审核、监控、数据分析等能力。

#### 存储、分发与协议

说明对象存储、CDN、边缘节点和图中明确标注的协议。

#### 视觉编码说明

说明背景、层级、模块颜色、箭头样式和阅读方向。
```

### 第九步：资源分类汇总

文档末尾必须生成：

```markdown
<!-- resource-index:start -->
# 资源分类汇总
...
<!-- resource-index:end -->
```

每类资源列出：

- 分类名称和数量；
- 显示名称；
- 资源编号；
- 原始图片文件名；
- 资源路径；
- 对应 Markdown 章节；
- 资源用途；
- 置信度和复核状态。

每个保留资源必须且只能出现一次。

装饰性资源默认不列入，除非配置明确要求。

### 第十步：校验

运行：

```bash
python scripts/validate_output.py \
  --markdown "<最终 Markdown>" \
  --manifest "<figure_manifest.json>" \
  --inventory "<image_inventory.json>" \
  --report "<validation_report.md>" \
  --require-ai-images
```

检查：

1. 所有输入图片均出现在图片清单；
2. 所有保留资源均有对应图片文件；
3. 所有 Markdown 图片路径有效；
4. 资源编号唯一；
5. 图片编号引用有效；
6. 所有保留资源均被插入正文；
7. 所有保留资源均在分类汇总中恰好出现一次；
8. 架构类图片具有架构描述；
9. 架构类图片具有视觉说明；
10. 架构类图片记录布局；
11. 架构类图片记录背景；
12. 点播与直播图片具有 `streaming_profile`；
13. 纯直播图具有直播媒体链路；
14. 纯点播图具有点播媒体链路；
15. 点播直播融合图同时具有两条媒体链路；
16. 互动直播图具有互动链路；
17. 电商直播图区分业务流与资金流；
18. 低置信度信息进入校验报告；
19. 未解析文字未被编造；
20. 原始 Markdown 未被覆盖；
21. 最终文件为 UTF-8。

## 8. 完成标准

任务完成必须满足：

- 图片成功准备并生成 `image_inventory.json`；
- 每张保留图片均有 `figure_manifest.json` 记录；
- 架构图保留原图并生成结构解析；
- 背景、颜色、排版、分组、箭头和层级得到说明；
- 未提供 Markdown 时生成独立完整文档；
- 提供 Markdown 时生成非破坏性的增强文档；
- 文档末尾存在完整资源分类汇总；
- 独立模式已生成 AI 可识别 SVG 与 PNG；
- 独立 Markdown 已引用 AI 标准化重绘图；
- 已生成 `ai_diagram_manifest.json`；
- 已生成校验报告；
- 校验报告不存在缺失文件错误；
- 原始输入文件未被覆盖。
