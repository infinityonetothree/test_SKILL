<!-- figure:{{figure_id}}:start -->
### {{display_name}}

![{{display_name}}]({{asset_path}})

*图 {{figure_number}}：{{caption}}。*

#### 架构概述

{{architecture_description}}

#### 模块组成

{{module_summary}}

#### 信息流与关系

{{relationship_summary}}

#### 视觉编码说明

{{visual_description}}
<!-- figure:{{figure_id}}:end -->
