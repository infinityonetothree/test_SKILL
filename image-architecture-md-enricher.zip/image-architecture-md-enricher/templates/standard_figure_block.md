<!-- figure:{{figure_id}}:start -->
### {{display_name}}

![{{display_name}}]({{asset_path}})

*图 {{figure_number}}：{{caption}}。*

{{one_sentence_summary}}

#### 视觉说明

{{visual_description}}
<!-- figure:{{figure_id}}:end -->
