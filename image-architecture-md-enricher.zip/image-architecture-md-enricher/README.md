# image-architecture-md-enricher

该 Skill 只要求输入图片。Markdown 为可选输入。

## 1. 两种使用方式

### 独立描述

```text
图片
→ 图片清单
→ Agent 视觉解析
→ figure_manifest.json
→ architecture_description.md
```

### 增强已有 Markdown

```text
图片 + summary.md
→ 图片清单
→ Agent 视觉解析
→ figure_manifest.json
→ summary_enriched.md
```

## 2. 文件结构

```text
image-architecture-md-enricher/
├── SKILL.md
├── README.md
├── VERSION
├── requirements.txt
├── scripts/
│   ├── prepare_images.py
│   ├── build_markdown.py
│   └── validate_output.py
├── schemas/
│   ├── image_inventory.schema.json
│   └── figure_manifest.schema.json
├── templates/
│   ├── architecture_block.md
│   └── standard_figure_block.md
├── examples/
│   ├── figure_manifest.example.json
│   └── source_summary.example.md
└── tools/
    ├── install_dependencies.ps1
    └── package_skill.ps1
```

## 3. 本机编辑

推荐使用 VS Code。

必须注意：

- 文件夹名称应为 `image-architecture-md-enricher`；
- `SKILL.md` 不能变成 `SKILL.md.txt`；
- 所有文本文件使用 UTF-8；
- 不要写死当前电脑的绝对路径；
- 不要把 `.venv`、缓存、测试图片和输出目录放入迁移包。

## 4. 静态检查

进入 Skill 根目录：

```powershell
cd D:\agent-skill-work\image-architecture-md-enricher
```

检查 Python：

```powershell
python -m py_compile scripts\prepare_images.py
python -m py_compile scripts\build_markdown.py
python -m py_compile scripts\validate_output.py
```

检查 JSON：

```powershell
python -m json.tool schemas\image_inventory.schema.json > $null
python -m json.tool schemas\figure_manifest.schema.json > $null
python -m json.tool examples\figure_manifest.example.json > $null
```

## 5. 安装依赖

```powershell
powershell -ExecutionPolicy Bypass -File tools\install_dependencies.ps1
```

## 6. 准备图片

单张图片：

```powershell
python scripts\prepare_images.py `
  --input "D:\test\architecture.png" `
  --output-dir "D:\test\output"
```

多张图片或目录：

```powershell
python scripts\prepare_images.py `
  --input "D:\test\architecture.png" `
  --input "D:\test\figures" `
  --output-dir "D:\test\output"
```

## 7. 生成 Markdown

无原始 Markdown：

```powershell
python scripts\build_markdown.py `
  --manifest "D:\test\output\manifests\figure_manifest.json" `
  --output "D:\test\output\architecture_description.md" `
  --title "系统架构图解析"
```

有原始 Markdown：

```powershell
python scripts\build_markdown.py `
  --manifest "D:\test\output\manifests\figure_manifest.json" `
  --source-md "D:\test\summary.md" `
  --output "D:\test\output\summary_enriched.md"
```

## 8. 校验

```powershell
python scripts\validate_output.py `
  --markdown "D:\test\output\architecture_description.md" `
  --manifest "D:\test\output\manifests\figure_manifest.json" `
  --inventory "D:\test\output\manifests\image_inventory.json" `
  --report "D:\test\output\reports\validation_report.md"
```

## 9. 打包迁移

```powershell
powershell -ExecutionPolicy Bypass -File tools\package_skill.ps1
```

会在 Skill 上一级生成：

```text
image-architecture-md-enricher.zip
```

## 10. 目标 Agent 端首次测试指令

### 仅图片

```text
请使用 image-architecture-md-enricher Skill 分析以下图片目录：

D:\test\images

输出目录：

D:\test\output

不提供原始 Markdown。请生成可独立阅读的 Markdown 文档，逐张说明图片类型、
架构模块、信息流、背景颜色、颜色分组、排版、箭头和层级，并在末尾生成资源分类汇总。
```

### 图片加 Markdown

```text
请使用 image-architecture-md-enricher Skill 处理：

图片目录：D:\test\images
已有总结：D:\test\summary.md
输出目录：D:\test\output

不要覆盖原始 Markdown。将图片和解析插入相关章节，并生成资源分类汇总和校验报告。
```
