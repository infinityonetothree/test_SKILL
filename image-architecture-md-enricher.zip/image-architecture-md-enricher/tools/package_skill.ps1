$ErrorActionPreference = "Stop"

$SkillRoot = Split-Path -Parent $PSScriptRoot
$Parent = Split-Path -Parent $SkillRoot
$SkillName = Split-Path -Leaf $SkillRoot
$TempRoot = Join-Path $env:TEMP ("skill-package-" + [guid]::NewGuid().ToString())
$TempSkill = Join-Path $TempRoot $SkillName
$ZipPath = Join-Path $Parent ($SkillName + ".zip")

New-Item -ItemType Directory -Path $TempSkill -Force | Out-Null

$ExcludedNames = @(".venv", "__pycache__", ".git", "output", "work", "test-output")
Get-ChildItem -Path $SkillRoot -Force | ForEach-Object {
    if ($ExcludedNames -notcontains $_.Name -and $_.Extension -ne ".zip") {
        Copy-Item $_.FullName -Destination $TempSkill -Recurse -Force
    }
}

if (Test-Path $ZipPath) {
    Remove-Item $ZipPath -Force
}

Compress-Archive -Path $TempSkill -DestinationPath $ZipPath -CompressionLevel Optimal
Remove-Item $TempRoot -Recurse -Force

Write-Host "已生成：$ZipPath"
