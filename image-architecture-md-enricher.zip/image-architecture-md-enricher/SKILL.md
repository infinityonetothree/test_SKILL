---
name: image-architecture-md-enricher
description: >
  分析一张或多张架构图、流程图、数据流图、模块框图及其他图片资源，
  保留并描述图片中的布局、背景颜色、模块颜色、视觉分组、节点、箭头、
  层级和信息流。Markdown 输入为可选：未提供 Markdown 时生成独立的
  架构图解析文档；提供 Markdown 时将图片及解析插入相关章节，并在文档
  末尾生成按分类汇总的完整资源列表和校验报告。
---

# Image Architecture Markdown Enricher

## 1. 目标

本 Skill 以图片为唯一必需输入，不依赖 PowerPoint 文件。

支持两种运行模式：

### 模式 A：独立描述模式

输入：

- 一张图片；
- 多张图片；
- 一个包含图片的目录。

不提供 Markdown。

输出：

- 一份完整的 Markdown 图片解析文档；
- 规范命名后的图片资源；
- 图片清单；
- 图片语义分析清单；
- 分类资源汇总；
- 校验报告。

### 模式 B：Markdown 增强模式

输入：

- 一张或多张图片；
- 一份已有 Markdown 文档。

输出：

- 在已有 Markdown 基础上插入图片及解析文本的增强文档；
- 分类资源汇总；
- 校验报告。

不得覆盖原始图片和原始 Markdown。

## 2. 输入

### 2.1 必需输入

至少提供以下一种图片输入形式：

1. 单张图片文件；
2. 多个图片文件；
3. 一个包含图片的目录。

默认支持：

- `.png`
- `.jpg`
- `.jpeg`
- `.webp`
- `.bmp`
- `.tif`
- `.tiff`

如果输入为 SVG、PDF、PPT 或其他格式，应先转换为普通图片，再使用本 Skill。

### 2.2 可选输入

- 已有 `.md` 文档；
- 输出文档标题；
- 输出语言，默认 `zh-CN`；
- 是否包含装饰性资源，默认 `false`；
- 图片分类自动接受阈值，默认 `0.75`；
- Markdown 插入位置自动接受阈值，默认 `0.75`；
- 是否保留低置信度图片，默认 `true`。

## 3. 输出

推荐输出结构：

```text
output/
├── architecture_description.md
├── assets/
│   ├── architecture/
│   ├── workflow/
│   ├── result/
│   ├── hardware/
│   ├── screenshot/
│   └── other/
├── manifests/
│   ├── image_inventory.json
│   ├── figure_manifest.json
│   └── insertion_manifest.json
└── reports/
    └── validation_report.md
```

在 Markdown 增强模式中，主输出文件可命名为：

```text
summary_enriched.md
```

## 4. 核心原则

1. 图片是唯一必需输入，不能要求用户补充 PPT。
2. Markdown 是可选输入；没有 Markdown 时必须生成可独立阅读的完整文档。
3. 复杂架构图必须同时保留原图引用和文字解析，不能只输出普通摘要。
4. 不能只识别图片文字，还要解析空间布局、背景、颜色、边框、包含关系、箭头和层级。
5. 背景颜色和排版不能在转为文字时丢失。
6. 颜色含义只有在图例、重复使用、附近标签或整体语义支持时才能确定。
7. 无法辨识的文字、模块和关系必须标记为“不确定”或“无法辨识”，不得猜测。
8. 多张图片必须逐张分析，并在文档末尾按分类汇总全部保留资源。
9. 每个保留资源必须有唯一编号，并且在资源分类汇总中恰好出现一次。
10. 如果提供已有 Markdown，应尽量保持原文、标题层级和章节顺序不变。
11. 所有最终图片引用必须使用相对路径。
12. 脚本负责确定性处理；Agent 负责视觉和语义判断。

## 5. Agent 与脚本的职责

### 5.1 脚本负责

- 收集单张、多张或目录中的图片；
- 校验图片是否可读取；
- 统一图片方向；
- 复制或转换为标准资源文件；
- 记录尺寸、宽高比、模式和文件哈希；
- 估计边角背景颜色和主要颜色；
- 生成 `image_inventory.json`；
- 根据 `figure_manifest.json` 生成或增强 Markdown；
- 生成资源分类汇总；
- 检查资源路径、重复编号、遗漏和描述完整性。

### 5.2 Agent 负责

- 查看每张图片；
- 判断图片类型；
- 判断是否为架构类图片；
- 给图片命名；
- 读取可辨识标签；
- 识别模块、层级、箭头和信息流；
- 解释布局、背景和颜色分组；
- 生成图片描述；
- 在有 Markdown 时判断插入章节和位置；
- 标记低置信度信息。

## 6. 资源分类

必须从下列类型中选择：

- `system_architecture`
- `layered_architecture`
- `data_flow`
- `workflow`
- `module_block_diagram`
- `training_pipeline`
- `control_architecture`
- `network_architecture`
- `deployment_architecture`
- `experimental_result`
- `table`
- `hardware_photo`
- `software_screenshot`
- `formula`
- `decorative`
- `unknown`

架构类资源包括：

- `system_architecture`
- `layered_architecture`
- `data_flow`
- `workflow`
- `module_block_diagram`
- `training_pipeline`
- `control_architecture`
- `network_architecture`
- `deployment_architecture`

## 7. 执行流程

### 第一步：准备图片

运行：

```bash
python scripts/prepare_images.py \
  --input "<图片或图片目录>" \
  --output-dir "<输出目录>"
```

可以重复提供 `--input`：

```bash
python scripts/prepare_images.py \
  --input "<图片1>" \
  --input "<图片2>" \
  --input "<图片目录>" \
  --output-dir "<输出目录>"
```

Windows PowerShell 示例：

```powershell
python scripts\prepare_images.py `
  --input "D:\work\architecture.png" `
  --input "D:\work\other_images" `
  --output-dir "D:\work\output"
```

该步骤必须生成：

```text
<输出目录>/
├── assets/
│   └── source/
└── manifests/
    └── image_inventory.json
```

`image_inventory.json` 至少记录：

- 图片编号；
- 原始文件名；
- 原始路径；
- 标准化后的资源路径；
- 宽度和高度；
- 宽高比；
- 色彩模式；
- 文件格式；
- SHA-256；
- 边角背景颜色估计；
- 主要颜色估计；
- 是否包含透明通道；
- 处理警告。

图片编号格式：

```text
IMG-001
IMG-002
```

### 第二步：Agent 逐张查看图片

Agent 必须查看 `image_inventory.json` 中的每一张图片。

不得只根据文件名判断图片内容。

对于每张图片：

1. 判断分类；
2. 判断是否保留；
3. 生成显示名称；
4. 生成简短图注；
5. 生成一句话摘要；
6. 识别主要文字；
7. 分析布局、背景、颜色和视觉分组；
8. 对架构类图片识别节点、连接关系、层级和反馈路径；
9. 确定是否需要人工复核。

### 第三步：生成 `figure_manifest.json`

每张保留图片至少包含：

- `figure_id`
- `image_id`
- `classification`
- `classification_confidence`
- `retain`
- `display_name`
- `asset_path`
- `caption`
- `one_sentence_summary`
- `visual_description`
- `review_required`

架构类图片还必须包含：

- `architecture_description`
- `module_summary`
- `relationship_summary`
- `layout`
- `background`
- `color_semantics`
- `nodes`
- `edges`

如果提供已有 Markdown，还应包含：

- `recommended_markdown_section`
- `insertion_anchor`
- `insertion_confidence`

资源编号格式：

```text
FIG-001
FIG-002
```

不得依赖原 PPT 页码。

### 第四步：解析背景与视觉结构

对每张架构类图片分析：

#### 4.1 背景

记录：

- 主背景颜色；
- 是否有透明背景；
- 是否存在渐变；
- 是否存在多个背景分区；
- 背景分区是否表达层级、阶段或模块边界；
- 背景与前景文字的对比方式。

脚本给出的边角颜色和主要颜色仅作为辅助证据，Agent 必须以图片实际视觉为准。

#### 4.2 总体布局

布局类型从以下值中选择：

- `left_to_right`
- `right_to_left`
- `top_to_bottom`
- `bottom_to_top`
- `layered`
- `radial`
- `cyclic`
- `matrix`
- `swimlane`
- `central_hub`
- `hybrid`
- `unknown`

描述：

- 主要阅读方向；
- 主路径；
- 并行分支；
- 上下层级；
- 中心与外围；
- 输入和输出；
- 正向链路和反馈链路。

#### 4.3 节点

每个主要节点尽量记录：

- 节点编号；
- 原始标签；
- 中文名称；
- 相对位置；
- 形状；
- 填充颜色；
- 边框颜色；
- 文本颜色；
- 所属视觉分组；
- 语义角色；
- 置信度。

#### 4.4 连接关系

每条主要连接尽量记录：

- 源节点；
- 目标节点；
- 方向；
- 线型；
- 箭头类型；
- 边标签；
- 信息流、控制流、反馈流或依赖关系；
- 置信度。

#### 4.5 视觉编码

必须说明：

- 背景及背景分区；
- 模块颜色和视觉分组；
- 实线、虚线、边框和阴影；
- 重点模块如何突出；
- 包含关系和层级；
- 箭头方向和循环；
- 颜色语义是否确定。

颜色含义不明确时，应使用：

> 不同颜色用于区分模块或阶段，但图片未提供足够证据确定每种颜色的具体语义。

### 第五步：选择输出模式

#### 5.1 未提供 Markdown

生成独立文档：

```bash
python scripts/build_markdown.py \
  --manifest "<figure_manifest.json>" \
  --output "<architecture_description.md>" \
  --title "<可选文档标题>"
```

独立文档推荐结构：

```markdown
# 架构图解析

## 总体说明

本文件共解析若干张图片。

## 图片解析

### 图片一：名称

原图、图注、架构概述、模块组成、信息流与关系、视觉编码说明。

### 图片二：名称

……

# 资源分类汇总
```

#### 5.2 提供 Markdown

运行：

```bash
python scripts/build_markdown.py \
  --manifest "<figure_manifest.json>" \
  --source-md "<已有 Markdown>" \
  --output "<summary_enriched.md>"
```

必须：

- 不覆盖原始 Markdown；
- 尽量保持原文；
- 将图片插入相关章节；
- 无法匹配时建立“补充架构图解析”小节；
- 在末尾生成资源分类汇总。

### 第六步：Markdown 插入规则

有 Markdown 时，综合考虑：

```text
0.35 × 图片标签与 Markdown 标题相似度
+ 0.30 × 图片描述与 Markdown 段落相似度
+ 0.20 × 图片主要概念与章节关键词相似度
+ 0.10 × 图片输入顺序与 Markdown 章节顺序一致性
+ 0.05 × “如图所示、整体架构、流程如下”等显式引用匹配
```

处理规则：

- `insertion_confidence >= 0.75`：自动插入相关章节；
- `0.55 <= insertion_confidence < 0.75`：插入相关章节末尾，并标记复核；
- `< 0.55`：放入“补充架构图解析”小节，并标记复核。

如提供 `insertion_anchor`，优先插入包含该锚点文本的段落之后。

### 第七步：标准图片解析块

架构类图片：

```markdown
<!-- figure:FIG-001:start -->
### 分层运动控制系统架构

![分层运动控制系统架构](assets/architecture/fig_001_hierarchical_control_architecture.png)

*图 1：任务指令、策略网络、底层控制器与机器人本体形成的闭环架构。*

#### 架构概述

架构整体说明。

#### 模块组成

- 模块一：作用。
- 模块二：作用。

#### 信息流与关系

1. 模块一向模块二传递信息。
2. 模块二生成输出。
3. 状态通过反馈路径返回。

#### 视觉编码说明

- 背景颜色及背景分区。
- 总体排版和阅读方向。
- 模块颜色和视觉分组。
- 箭头、边框、虚线和阴影。
- 层级关系及重点模块。
<!-- figure:FIG-001:end -->
```

非架构类图片可以省略模块和关系小节，但必须保留原图、图注、摘要和视觉说明。

### 第八步：资源分类汇总

文档末尾必须生成：

```markdown
<!-- resource-index:start -->
# 资源分类汇总
...
<!-- resource-index:end -->
```

每类资源列出：

- 分类名称和数量；
- 显示名称；
- 资源编号；
- 原始图片文件名；
- 资源路径；
- 对应 Markdown 章节；
- 资源用途；
- 置信度和复核状态。

每个保留资源必须且只能出现一次。

装饰性资源默认不列入，除非配置明确要求。

### 第九步：校验

运行：

```bash
python scripts/validate_output.py \
  --markdown "<最终 Markdown>" \
  --manifest "<figure_manifest.json>" \
  --inventory "<image_inventory.json>" \
  --report "<validation_report.md>"
```

检查：

1. 所有输入图片均出现在图片清单；
2. 所有保留资源均有对应图片文件；
3. 所有 Markdown 图片路径有效；
4. 资源编号唯一；
5. 图片编号引用有效；
6. 所有保留资源均被插入正文；
7. 所有保留资源均在分类汇总中恰好出现一次；
8. 架构类图片具有架构描述；
9. 架构类图片具有视觉说明；
10. 架构类图片记录布局；
11. 架构类图片记录背景；
12. 低置信度信息进入校验报告；
13. 未解析文字未被编造；
14. 原始 Markdown 未被覆盖；
15. 最终文件为 UTF-8。

## 8. 完成标准

任务完成必须满足：

- 图片成功准备并生成 `image_inventory.json`；
- 每张保留图片均有 `figure_manifest.json` 记录；
- 架构图保留原图并生成结构解析；
- 背景、颜色、排版、分组、箭头和层级得到说明；
- 未提供 Markdown 时生成独立完整文档；
- 提供 Markdown 时生成非破坏性的增强文档；
- 文档末尾存在完整资源分类汇总；
- 已生成校验报告；
- 校验报告不存在缺失文件错误；
- 原始输入文件未被覆盖。
