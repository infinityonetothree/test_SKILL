#!/usr/bin/env python3
"""Create a standalone image-analysis Markdown or enrich an existing Markdown."""

from __future__ import annotations

import argparse
import json
import re
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


ARCHITECTURE_TYPES = {
    "system_architecture",
    "layered_architecture",
    "data_flow",
    "workflow",
    "module_block_diagram",
    "training_pipeline",
    "control_architecture",
    "network_architecture",
    "deployment_architecture",
}

CLASSIFICATION_LABELS = {
    "system_architecture": "系统架构图",
    "layered_architecture": "分层架构图",
    "data_flow": "数据流图",
    "workflow": "流程图",
    "module_block_diagram": "模块框图",
    "training_pipeline": "训练流程图",
    "control_architecture": "控制架构图",
    "network_architecture": "网络架构图",
    "deployment_architecture": "部署架构图",
    "experimental_result": "实验结果图",
    "table": "表格资源",
    "hardware_photo": "硬件与实验平台照片",
    "software_screenshot": "软件截图",
    "formula": "公式资源",
    "unknown": "未分类或待复核资源",
}


def load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def normalize_heading(text: str) -> str:
    text = re.sub(r"[`*_~\[\](){}<>:：,，.。/\\\-—_]+", " ", text)
    return re.sub(r"\s+", " ", text).strip().casefold()


def find_heading(lines: List[str], target: str) -> Optional[Tuple[int, int]]:
    normalized_target = normalize_heading(target)
    if not normalized_target:
        return None

    candidates: List[Tuple[float, int, int]] = []
    for index, line in enumerate(lines):
        match = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if not match:
            continue
        level = len(match.group(1))
        heading = normalize_heading(match.group(2))
        if heading == normalized_target:
            return index, level
        if normalized_target in heading or heading in normalized_target:
            ratio = min(len(heading), len(normalized_target)) / max(
                len(heading), len(normalized_target)
            )
            candidates.append((ratio, index, level))

    if not candidates:
        return None
    candidates.sort(reverse=True)
    return candidates[0][1], candidates[0][2]


def section_end(lines: List[str], heading_index: int, heading_level: int) -> int:
    for index in range(heading_index + 1, len(lines)):
        match = re.match(r"^(#{1,6})\s+", lines[index])
        if match and len(match.group(1)) <= heading_level:
            return index
    return len(lines)


def paragraph_end(lines: List[str], start: int, end: int) -> int:
    index = start
    while index < end and lines[index].strip():
        index += 1
    return index


def anchor_insert_position(
    lines: List[str], start: int, end: int, anchor: str
) -> Optional[int]:
    if not anchor:
        return None
    for index in range(start, end):
        if anchor in lines[index]:
            return paragraph_end(lines, index + 1, end)
    return None


def default_insert_position(lines: List[str], heading_index: int, end: int) -> int:
    index = heading_index + 1
    while index < end and not lines[index].strip():
        index += 1
    if index >= end or re.match(r"^#{1,6}\s+", lines[index]):
        return heading_index + 1
    return paragraph_end(lines, index, end)


def as_bullets(value: Any) -> str:
    if isinstance(value, list):
        items = [str(item).strip() for item in value if str(item).strip()]
        return "\n".join(f"- {item}" for item in items) or "- 暂无可靠信息。"
    text = str(value or "").strip()
    return text or "- 暂无可靠信息。"


def as_numbered(value: Any) -> str:
    if isinstance(value, list):
        items = [str(item).strip() for item in value if str(item).strip()]
        return "\n".join(f"{index}. {item}" for index, item in enumerate(items, 1)) or "1. 暂无可靠信息。"
    text = str(value or "").strip()
    return text or "1. 暂无可靠信息。"


def architecture_block(figure: Dict[str, Any], figure_number: int) -> str:
    figure_id = figure["figure_id"]
    display_name = figure.get("display_name", figure_id)
    asset_path = str(figure.get("asset_path", "")).replace("\\", "/")
    caption = figure.get("caption", "")
    return (
        f"<!-- figure:{figure_id}:start -->\n"
        f"### {display_name}\n\n"
        f"![{display_name}]({asset_path})\n\n"
        f"*图 {figure_number}：{caption}。*\n\n"
        f"#### 架构概述\n\n"
        f"{figure.get('architecture_description', '').strip() or '暂无可靠的架构概述。'}\n\n"
        f"#### 模块组成\n\n"
        f"{as_bullets(figure.get('module_summary'))}\n\n"
        f"#### 信息流与关系\n\n"
        f"{as_numbered(figure.get('relationship_summary'))}\n\n"
        f"#### 视觉编码说明\n\n"
        f"{figure.get('visual_description', '').strip() or '暂无可靠的视觉编码说明。'}\n"
        f"<!-- figure:{figure_id}:end -->"
    )


def standard_block(figure: Dict[str, Any], figure_number: int) -> str:
    figure_id = figure["figure_id"]
    display_name = figure.get("display_name", figure_id)
    asset_path = str(figure.get("asset_path", "")).replace("\\", "/")
    caption = figure.get("caption", "")
    summary = figure.get("one_sentence_summary", "").strip()
    visual = figure.get("visual_description", "").strip()
    body = summary
    if visual:
        body += f"\n\n#### 视觉说明\n\n{visual}"
    return (
        f"<!-- figure:{figure_id}:start -->\n"
        f"### {display_name}\n\n"
        f"![{display_name}]({asset_path})\n\n"
        f"*图 {figure_number}：{caption}。*\n\n"
        f"{body}\n"
        f"<!-- figure:{figure_id}:end -->"
    )


def remove_existing_resource_index(text: str) -> str:
    pattern = re.compile(
        r"\n?<!-- resource-index:start -->.*?<!-- resource-index:end -->\n?",
        flags=re.DOTALL,
    )
    return pattern.sub("\n", text).rstrip() + "\n"


def resource_index(figures: List[Dict[str, Any]]) -> str:
    grouped: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for figure in figures:
        if not figure.get("retain", True):
            continue
        classification = figure.get("classification", "unknown")
        if classification == "decorative":
            continue
        grouped[classification].append(figure)

    lines = ["<!-- resource-index:start -->", "# 资源分类汇总", ""]
    ordered_types = list(CLASSIFICATION_LABELS.keys())

    for classification in ordered_types:
        items = grouped.pop(classification, [])
        if not items:
            continue
        label = CLASSIFICATION_LABELS.get(classification, classification)
        lines.append(f"## {label}（{len(items)}项）")
        lines.append("")
        for index, figure in enumerate(items, 1):
            lines.append(
                f"{index}. **{figure.get('display_name', figure.get('figure_id', '未命名资源'))}**"
            )
            lines.append(f"   - 资源编号：{figure.get('figure_id', '')}")
            lines.append(f"   - 原始文件：`{figure.get('original_name', '')}`")
            lines.append(
                f"   - 文件：`{str(figure.get('asset_path', '')).replace(chr(92), '/')}`"
            )
            lines.append(
                f"   - 对应章节：{figure.get('recommended_markdown_section', '独立图片解析') or '独立图片解析'}"
            )
            lines.append(
                f"   - 作用：{figure.get('one_sentence_summary', '') or figure.get('caption', '')}"
            )
            confidence = float(figure.get("classification_confidence", 1.0))
            if confidence < 0.75 or figure.get("review_required", False):
                lines.append(
                    f"   - 复核状态：需要复核，分类置信度 {confidence:.2f}"
                )
            lines.append("")

    for classification, items in sorted(grouped.items()):
        lines.append(f"## {classification}（{len(items)}项）")
        lines.append("")
        for index, figure in enumerate(items, 1):
            lines.append(
                f"{index}. **{figure.get('display_name', figure.get('figure_id', '未命名资源'))}**"
            )
            lines.append(f"   - 资源编号：{figure.get('figure_id', '')}")
            lines.append("")

    lines.append("<!-- resource-index:end -->")
    return "\n".join(lines)


def retained_figures(manifest: Dict[str, Any]) -> List[Dict[str, Any]]:
    return [
        figure
        for figure in manifest.get("figures", [])
        if figure.get("retain", True)
        and figure.get("classification") != "decorative"
    ]


def create_standalone(
    figures: List[Dict[str, Any]], title: str
) -> str:
    lines = [
        f"# {title}",
        "",
        "## 总体说明",
        "",
        f"本文件共解析 {len(figures)} 张保留图片。图片按照输入顺序列出，并在文档末尾按资源类型汇总。",
        "",
        "## 图片解析",
        "",
    ]

    for number, figure in enumerate(figures, 1):
        classification = figure.get("classification", "unknown")
        block = (
            architecture_block(figure, number)
            if classification in ARCHITECTURE_TYPES
            else standard_block(figure, number)
        )
        lines.extend([block, ""])

    lines.extend([resource_index(figures), ""])
    return "\n".join(lines)


def enrich_existing(
    source_text: str, figures: List[Dict[str, Any]]
) -> str:
    text = remove_existing_resource_index(source_text)
    lines = text.splitlines()
    figure_number = 1

    for figure in figures:
        figure_id = figure.get("figure_id", "")
        if not figure_id:
            continue
        if f"<!-- figure:{figure_id}:start -->" in "\n".join(lines):
            continue

        classification = figure.get("classification", "unknown")
        block = (
            architecture_block(figure, figure_number)
            if classification in ARCHITECTURE_TYPES
            else standard_block(figure, figure_number)
        )
        target = figure.get("recommended_markdown_section", "")
        heading = find_heading(lines, target) if target else None

        if heading is None:
            fallback = (
                "## 补充架构图解析"
                if classification in ARCHITECTURE_TYPES
                else "## 补充视觉资源"
            )
            if fallback not in lines:
                lines.extend(["", fallback, ""])
            heading_index = lines.index(fallback)
            level = len(fallback.split(" ", 1)[0])
            insert_at = section_end(lines, heading_index, level)
        else:
            heading_index, level = heading
            end = section_end(lines, heading_index, level)
            insert_at = (
                anchor_insert_position(
                    lines,
                    heading_index + 1,
                    end,
                    str(figure.get("insertion_anchor", "")),
                )
                or default_insert_position(lines, heading_index, end)
            )

        lines[insert_at:insert_at] = ["", block, ""]
        figure_number += 1

    return (
        "\n".join(lines).rstrip()
        + "\n\n"
        + resource_index(figures)
        + "\n"
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--source-md")
    parser.add_argument("--title", default="架构图与视觉资源解析")
    args = parser.parse_args()

    manifest_path = Path(args.manifest).expanduser().resolve()
    output_path = Path(args.output).expanduser().resolve()

    if not manifest_path.exists():
        print(f"ERROR: manifest not found: {manifest_path}", file=sys.stderr)
        return 2

    try:
        manifest = load_json(manifest_path)
    except Exception as exc:
        print(f"ERROR: cannot read manifest: {exc}", file=sys.stderr)
        return 3

    figures = retained_figures(manifest)
    title = str(manifest.get("document_title") or args.title)

    if args.source_md:
        source_path = Path(args.source_md).expanduser().resolve()
        if not source_path.exists():
            print(f"ERROR: source Markdown not found: {source_path}", file=sys.stderr)
            return 2
        if source_path == output_path:
            print("ERROR: output must not overwrite source Markdown.", file=sys.stderr)
            return 2
        try:
            source_text = source_path.read_text(encoding="utf-8")
        except Exception as exc:
            print(f"ERROR: cannot read source Markdown: {exc}", file=sys.stderr)
            return 3
        result = enrich_existing(source_text, figures)
    else:
        result = create_standalone(figures, title)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(result, encoding="utf-8")
    print(f"Created: {output_path}")
    print(
        "Mode:",
        "Markdown enrichment" if args.source_md else "standalone description",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
