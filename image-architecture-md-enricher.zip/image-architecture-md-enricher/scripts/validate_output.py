#!/usr/bin/env python3
"""Validate generated Markdown, image inventory, and figure manifest."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List


ARCHITECTURE_TYPES = {
    "system_architecture",
    "layered_architecture",
    "data_flow",
    "workflow",
    "module_block_diagram",
    "training_pipeline",
    "control_architecture",
    "network_architecture",
    "deployment_architecture",
}


def load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def markdown_image_paths(markdown: str) -> List[str]:
    return re.findall(r"!\[[^\]]*\]\(([^)]+)\)", markdown)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--markdown", required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--inventory", required=True)
    parser.add_argument("--report", required=True)
    parser.add_argument(
        "--assets-root",
        help="Base directory for asset paths; defaults to Markdown parent.",
    )
    args = parser.parse_args()

    markdown_path = Path(args.markdown).expanduser().resolve()
    manifest_path = Path(args.manifest).expanduser().resolve()
    inventory_path = Path(args.inventory).expanduser().resolve()
    report_path = Path(args.report).expanduser().resolve()
    assets_root = (
        Path(args.assets_root).expanduser().resolve()
        if args.assets_root
        else markdown_path.parent
    )

    errors: List[str] = []
    warnings: List[str] = []
    passed: List[str] = []

    try:
        markdown = markdown_path.read_text(encoding="utf-8")
        manifest = load_json(manifest_path)
        inventory = load_json(inventory_path)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    inventory_images = inventory.get("images", [])
    inventory_ids = {
        str(image.get("image_id", "")): image for image in inventory_images
    }
    figures = manifest.get("figures", [])
    retained = [
        figure
        for figure in figures
        if figure.get("retain", True)
        and figure.get("classification") != "decorative"
    ]

    figure_ids = [str(figure.get("figure_id", "")) for figure in retained]
    duplicate_figure_ids = sorted(
        {item for item in figure_ids if item and figure_ids.count(item) > 1}
    )
    if duplicate_figure_ids:
        errors.append(
            f"重复资源编号：{', '.join(duplicate_figure_ids)}"
        )
    else:
        passed.append("资源编号唯一。")

    used_image_ids: List[str] = []
    for figure in retained:
        figure_id = str(figure.get("figure_id", ""))
        image_id = str(figure.get("image_id", ""))
        used_image_ids.append(image_id)

        if image_id not in inventory_ids:
            errors.append(
                f"{figure_id} 引用了不存在的图片编号：{image_id}"
            )

        marker = f"<!-- figure:{figure_id}:start -->"
        if marker not in markdown:
            errors.append(f"{figure_id} 未插入 Markdown。")

        asset_path = str(figure.get("asset_path", "")).replace("\\", "/")
        if not asset_path:
            errors.append(f"{figure_id} 缺少 asset_path。")
        else:
            resolved = assets_root / Path(asset_path)
            if not resolved.exists():
                errors.append(
                    f"{figure_id} 的资源文件不存在：{resolved}"
                )

        classification = figure.get("classification")
        if classification in ARCHITECTURE_TYPES:
            if not str(
                figure.get("architecture_description", "")
            ).strip():
                errors.append(
                    f"{figure_id} 缺少 architecture_description。"
                )
            if not str(
                figure.get("visual_description", "")
            ).strip():
                errors.append(
                    f"{figure_id} 缺少 visual_description。"
                )
            if not isinstance(figure.get("layout"), dict):
                warnings.append(f"{figure_id} 缺少结构化 layout。")
            if not isinstance(figure.get("background"), dict):
                warnings.append(
                    f"{figure_id} 缺少结构化 background。"
                )

        classification_confidence = float(
            figure.get("classification_confidence", 1.0)
        )
        insertion_confidence = float(
            figure.get("insertion_confidence", 1.0)
        )
        if classification_confidence < 0.75:
            warnings.append(
                f"{figure_id} 分类置信度低于 0.75。"
            )
        if "insertion_confidence" in figure and insertion_confidence < 0.75:
            warnings.append(
                f"{figure_id} 插入位置置信度低于 0.75。"
            )
        if figure.get("review_required", False):
            warnings.append(
                f"{figure_id} 被标记为需要人工复核。"
            )

    if "<!-- resource-index:start -->" not in markdown or "<!-- resource-index:end -->" not in markdown:
        errors.append("缺少资源分类汇总标记。")
    else:
        passed.append("资源分类汇总存在。")

    for figure_id in figure_ids:
        count = markdown.count(f"资源编号：{figure_id}")
        if count != 1:
            errors.append(
                f"{figure_id} 在资源分类汇总中出现 {count} 次，应为 1 次。"
            )

    for image_path in markdown_image_paths(markdown):
        if "://" in image_path or image_path.startswith("data:"):
            continue
        resolved = assets_root / Path(image_path.replace("\\", "/"))
        if not resolved.exists():
            errors.append(
                f"Markdown 图片引用不存在：{resolved}"
            )

    # Inventory images can be intentionally discarded, but the report should show it.
    unused = [
        image_id
        for image_id in inventory_ids
        if image_id not in used_image_ids
    ]
    if unused:
        warnings.append(
            "以下输入图片未对应保留资源，可能被分类为装饰图或被遗漏："
            + ", ".join(unused)
        )
    else:
        passed.append("所有输入图片均对应至少一个保留资源。")

    report_lines = [
        "# Validation Report",
        "",
        f"- Markdown：`{markdown_path}`",
        f"- Figure manifest：`{manifest_path}`",
        f"- Image inventory：`{inventory_path}`",
        f"- 输入图片数量：{len(inventory_images)}",
        f"- 保留资源数量：{len(retained)}",
        f"- 错误数量：{len(errors)}",
        f"- 警告数量：{len(warnings)}",
        "",
        "## 结果",
        "",
        "PASS" if not errors else "FAIL",
        "",
    ]

    if errors:
        report_lines.extend(["## 错误", ""])
        report_lines.extend(f"- {item}" for item in errors)
        report_lines.append("")
    if warnings:
        report_lines.extend(["## 警告", ""])
        report_lines.extend(f"- {item}" for item in warnings)
        report_lines.append("")
    if passed:
        report_lines.extend(["## 已通过检查", ""])
        report_lines.extend(f"- {item}" for item in passed)
        report_lines.append("")

    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(
        "\n".join(report_lines),
        encoding="utf-8",
    )
    print(f"Created: {report_path}")
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
