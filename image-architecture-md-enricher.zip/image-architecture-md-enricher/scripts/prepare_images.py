#!/usr/bin/env python3
"""Collect, normalize, and inventory raster images for Agent analysis."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from collections import Counter
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from PIL import Image, ImageOps, UnidentifiedImageError


SUPPORTED_SUFFIXES = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff"}


def iter_input_files(inputs: Iterable[str]) -> List[Path]:
    files: List[Path] = []
    seen: set[Path] = set()

    for raw in inputs:
        path = Path(raw).expanduser().resolve()
        if not path.exists():
            raise FileNotFoundError(f"Input does not exist: {path}")

        candidates: Iterable[Path]
        if path.is_dir():
            candidates = sorted(
                p for p in path.rglob("*")
                if p.is_file() and p.suffix.lower() in SUPPORTED_SUFFIXES
            )
        else:
            if path.suffix.lower() not in SUPPORTED_SUFFIXES:
                raise ValueError(f"Unsupported image type: {path}")
            candidates = [path]

        for candidate in candidates:
            resolved = candidate.resolve()
            if resolved not in seen:
                seen.add(resolved)
                files.append(resolved)

    return files


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def rgb_hex(rgb: Tuple[int, int, int]) -> str:
    return "#{:02X}{:02X}{:02X}".format(*rgb)


def flatten_to_rgb(image: Image.Image) -> Image.Image:
    image = ImageOps.exif_transpose(image)
    if image.mode in ("RGBA", "LA") or "transparency" in image.info:
        rgba = image.convert("RGBA")
        background = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
        background.alpha_composite(rgba)
        return background.convert("RGB")
    return image.convert("RGB")


def estimate_corner_background(image: Image.Image) -> Optional[str]:
    rgb = flatten_to_rgb(image)
    width, height = rgb.size
    sample_size = max(1, min(width, height) // 50)
    points = [
        (0, 0, sample_size, sample_size),
        (max(0, width - sample_size), 0, width, sample_size),
        (0, max(0, height - sample_size), sample_size, height),
        (max(0, width - sample_size), max(0, height - sample_size), width, height),
    ]
    colors: List[Tuple[int, int, int]] = []
    for box in points:
        crop = rgb.crop(box).resize((1, 1))
        colors.append(tuple(crop.getpixel((0, 0))))
    if not colors:
        return None
    average = tuple(round(sum(color[i] for color in colors) / len(colors)) for i in range(3))
    return rgb_hex(average)


def dominant_colors(image: Image.Image, count: int = 5) -> List[Dict[str, Any]]:
    rgb = flatten_to_rgb(image)
    thumbnail = rgb.copy()
    thumbnail.thumbnail((256, 256))
    quantized = thumbnail.quantize(colors=count)
    palette = quantized.getpalette() or []
    counts = Counter(quantized.getdata())
    total = sum(counts.values()) or 1
    result: List[Dict[str, Any]] = []
    for palette_index, pixel_count in counts.most_common(count):
        offset = palette_index * 3
        if offset + 2 >= len(palette):
            continue
        color = (palette[offset], palette[offset + 1], palette[offset + 2])
        result.append({
            "rgb": rgb_hex(color),
            "fraction": round(pixel_count / total, 4),
        })
    return result


def safe_asset_name(index: int, source: Path) -> str:
    suffix = source.suffix.lower()
    if suffix in {".jpg", ".jpeg"}:
        suffix = ".jpg"
    elif suffix == ".tiff":
        suffix = ".tif"
    return f"img_{index:03d}{suffix}"


def prepare_one(source: Path, index: int, assets_dir: Path) -> Dict[str, Any]:
    warnings: List[str] = []
    try:
        with Image.open(source) as opened:
            original_format = opened.format or source.suffix.lstrip(".").upper()
            original_mode = opened.mode
            has_alpha = original_mode in ("RGBA", "LA") or "transparency" in opened.info
            normalized = ImageOps.exif_transpose(opened)
            width, height = normalized.size
            corner = estimate_corner_background(normalized)
            colors = dominant_colors(normalized)
    except (UnidentifiedImageError, OSError) as exc:
        raise ValueError(f"Cannot read image {source}: {exc}") from exc

    asset_name = safe_asset_name(index, source)
    destination = assets_dir / asset_name

    # Preserve original bytes when no EXIF rotation or extension normalization is needed.
    try:
        with Image.open(source) as opened:
            transposed = ImageOps.exif_transpose(opened)
            needs_save = transposed.size != opened.size or source.suffix.lower() != destination.suffix.lower()
            if needs_save:
                save_image = transposed
                if destination.suffix.lower() in {".jpg", ".jpeg"} and save_image.mode not in ("RGB", "L"):
                    save_image = flatten_to_rgb(save_image)
                save_image.save(destination)
                warnings.append("Image was normalized before copying.")
            else:
                shutil.copy2(source, destination)
    except Exception:
        shutil.copy2(source, destination)
        warnings.append("Normalization failed; original bytes were copied.")

    return {
        "image_id": f"IMG-{index:03d}",
        "original_name": source.name,
        "original_path": str(source),
        "asset_path": f"assets/source/{asset_name}",
        "width": width,
        "height": height,
        "aspect_ratio": round(width / height, 6),
        "format": original_format,
        "mode": original_mode,
        "has_alpha": has_alpha,
        "sha256": sha256_file(destination),
        "corner_background_rgb": corner,
        "dominant_colors": colors,
        "warnings": warnings,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--input",
        action="append",
        required=True,
        help="Image file or directory. Repeat this option for multiple inputs.",
    )
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    output_dir = Path(args.output_dir).expanduser().resolve()
    assets_dir = output_dir / "assets" / "source"
    manifests_dir = output_dir / "manifests"
    assets_dir.mkdir(parents=True, exist_ok=True)
    manifests_dir.mkdir(parents=True, exist_ok=True)

    try:
        inputs = iter_input_files(args.input)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    if not inputs:
        print("ERROR: no supported image files were found.", file=sys.stderr)
        return 2

    images: List[Dict[str, Any]] = []
    failures: List[str] = []
    for index, source in enumerate(inputs, start=1):
        try:
            images.append(prepare_one(source, index, assets_dir))
        except Exception as exc:
            failures.append(str(exc))

    if not images:
        print("ERROR: no image could be prepared.", file=sys.stderr)
        for failure in failures:
            print(f" - {failure}", file=sys.stderr)
        return 3

    inventory = {
        "images": images,
        "failures": failures,
    }
    inventory_path = manifests_dir / "image_inventory.json"
    inventory_path.write_text(
        json.dumps(inventory, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(f"Created: {inventory_path}")
    print(f"Prepared images: {len(images)}")
    if failures:
        print(f"Warnings: {len(failures)} image(s) failed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
